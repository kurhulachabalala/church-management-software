﻿CREATE TABLE [dbo].[families] (
    [familyID]        INT           IDENTITY (1, 1) NOT NULL,
    [familyName]      VARCHAR (100) NOT NULL,
    [Adress]          VARCHAR (300) NULL,
    [homeTel]         VARCHAR (50)  NULL,
    [cell1]           VARCHAR (50)  NULL,
    [cell2]           VARCHAR (50)  NULL,
    [email1]          VARCHAR (300) NULL,
    [email2]          VARCHAR (300) NULL,
    [sendnewsLetter]  INT           NULL,
    [lastEditeddated] DATETIME      NOT NULL,
    PRIMARY KEY CLUSTERED ([familyID] ASC)
);

