﻿CREATE TABLE [dbo].[familyEvents] (
    [familyEventsID]                  INT           IDENTITY (1, 1) NOT NULL,
    [familyID]                        INT           NULL,
    [eventsName]                      VARCHAR (50)  NULL,
    [eventAddress]                    VARCHAR (300) NULL,
    [event type]                      VARCHAR (50)  NULL,
    [event details]                   VARCHAR (50)  NULL,
    [event date]                      DATETIME      NULL,
    [event contact person]            VARCHAR (50)  NULL,
    [event contact person numbers]    VARCHAR (50)  NULL,
    [alt event contact person]        VARCHAR (50)  NULL,
    [alt event contact person number] VARCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([familyEventsID] ASC),
    CONSTRAINT [FK_familyEvents_families] FOREIGN KEY ([familyID]) REFERENCES [dbo].[families] ([familyID])
);

