﻿CREATE TABLE [dbo].[GroupsFunction] (
    [groupFunctionID] INT            IDENTITY (1, 1) NOT NULL,
    [name]            VARCHAR (100)  NOT NULL,
    [discription]     VARCHAR (1000) NULL,
    [mission]         VARCHAR (200)  NULL,
    [startDate]       DATETIME       NOT NULL,
    PRIMARY KEY CLUSTERED ([groupFunctionID] ASC)
);

