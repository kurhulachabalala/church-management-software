﻿CREATE TABLE [dbo].[memberGroup] (
    [memberGroupID]       INT          IDENTITY (1, 1) NOT NULL,
    [memberDetailsID]     INT          NULL,
    [groupFunctionID]     INT          NULL,
    [memberFunction]      VARCHAR (50) NULL,
    [functionDiscription] VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([memberGroupID] ASC),
    CONSTRAINT [FK_memberGroup_GroupsFunction1] FOREIGN KEY ([groupFunctionID]) REFERENCES [dbo].[GroupsFunction] ([groupFunctionID]),
    CONSTRAINT [FK_memberGroup_memberDetails1] FOREIGN KEY ([memberDetailsID]) REFERENCES [dbo].[memberDetails] ([memberDetailsID])
);

