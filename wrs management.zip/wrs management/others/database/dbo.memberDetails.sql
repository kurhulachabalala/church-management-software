﻿CREATE TABLE [dbo].[memberDetails] (
    [memberDetailsID] INT           IDENTITY (1, 1) NOT NULL,
    [name]            VARCHAR (100) NOT NULL,
    [surname]         INT           NOT NULL,
    [gender]          VARCHAR (100) NOT NULL,
    [membership]      VARCHAR (100) NOT NULL,
    [merital status]  VARCHAR (100) NOT NULL,
    [dateOfBirth]     DATETIME      NOT NULL,
    [Adress]          VARCHAR (300) NULL,
    [contactNumber]   VARCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([memberDetailsID] ASC),
    CONSTRAINT [FK_memberDetails_families1] FOREIGN KEY ([surname]) REFERENCES [dbo].[families] ([familyID])
);

