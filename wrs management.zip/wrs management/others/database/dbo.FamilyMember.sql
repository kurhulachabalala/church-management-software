﻿CREATE TABLE [dbo].[FamilyMember] (
    [family_mamberID] INT IDENTITY (1, 1) NOT NULL,
    [familyID]        INT NOT NULL,
    [memberDetailsID] INT NOT NULL,
    PRIMARY KEY CLUSTERED ([family_mamberID] ASC),
    CONSTRAINT [FK_FamilyMember_families] FOREIGN KEY ([familyID]) REFERENCES [dbo].[families] ([familyID]),
    CONSTRAINT [FK_FamilyMember_memberDetails] FOREIGN KEY ([memberDetailsID]) REFERENCES [dbo].[memberDetails] ([memberDetailsID])
);

