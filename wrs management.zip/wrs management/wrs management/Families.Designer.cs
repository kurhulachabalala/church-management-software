﻿namespace wrs_management
{
    partial class Families
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Families));
            this.familiesDataGridView = new System.Windows.Forms.DataGridView();
            this.familyIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.familyNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.homeTelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cell1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cell2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sendnewsLetterDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastEditeddatedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.familiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wrsMembersDataSet = new wrs_management.wrsMembersDataSet();
            this.NameLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.editButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.familyMembersSaveBTN = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.searchFamilyBTN = new System.Windows.Forms.Button();
            this.AddButton = new System.Windows.Forms.Button();
            this.familyEventsSaveBTN = new System.Windows.Forms.Button();
            this.FamiliesTabControl = new System.Windows.Forms.TabControl();
            this.FamilyDetailsTabPage = new System.Windows.Forms.TabPage();
            this.familyAddressRichTextBox = new System.Windows.Forms.RichTextBox();
            this.HomeTelLable = new System.Windows.Forms.Label();
            this.MeritalSCheckedListBox = new System.Windows.Forms.CheckedListBox();
            this.DOBNonApplicableCHKB = new System.Windows.Forms.CheckBox();
            this.lastEditedDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.Cell1Label = new System.Windows.Forms.Label();
            this.familyAddressLabel = new System.Windows.Forms.Label();
            this.DOBLabel = new System.Windows.Forms.Label();
            this.email2Lable = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.Cell2Lable = new System.Windows.Forms.Label();
            this.familyNameLabel = new System.Windows.Forms.Label();
            this.HomeTelTextBox = new System.Windows.Forms.TextBox();
            this.Email2TextBox = new System.Windows.Forms.TextBox();
            this.Email1TextBox = new System.Windows.Forms.TextBox();
            this.Cell2TextBox = new System.Windows.Forms.TextBox();
            this.Cell1textBox = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.familyNameTextBox = new System.Windows.Forms.TextBox();
            this.familyDetailsSaveBTN = new System.Windows.Forms.Button();
            this.familyMemberstabPage = new System.Windows.Forms.TabPage();
            this.familyMembersDataGridView = new System.Windows.Forms.DataGridView();
            this.AddNewMemberButton = new System.Windows.Forms.Button();
            this.FamilyEventsTabPage = new System.Windows.Forms.TabPage();
            this.familyEventsDataGridView = new System.Windows.Forms.DataGridView();
            this.MapsButton = new System.Windows.Forms.Button();
            this.EventDetailsRichTextBox = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.FamilyContactPersonLabel = new System.Windows.Forms.Label();
            this.EventDetailsLabel = new System.Windows.Forms.Label();
            this.FamilyContactPersonTelLabel = new System.Windows.Forms.Label();
            this.eventAdressLabel = new System.Windows.Forms.Label();
            this.eventNameLabel = new System.Windows.Forms.Label();
            this.FamilyContactPersonTextBox = new System.Windows.Forms.TextBox();
            this.FamilyContactPersonTelTextBox = new System.Windows.Forms.TextBox();
            this.eventNameTextBox = new System.Windows.Forms.TextBox();
            this.familiesTableAdapter = new wrs_management.wrsMembersDataSetTableAdapters.familiesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.familiesDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.familiesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrsMembersDataSet)).BeginInit();
            this.FamiliesTabControl.SuspendLayout();
            this.FamilyDetailsTabPage.SuspendLayout();
            this.familyMemberstabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.familyMembersDataGridView)).BeginInit();
            this.FamilyEventsTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.familyEventsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // familiesDataGridView
            // 
            this.familiesDataGridView.AllowUserToAddRows = false;
            this.familiesDataGridView.AllowUserToDeleteRows = false;
            this.familiesDataGridView.AutoGenerateColumns = false;
            this.familiesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.familiesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.familyIDDataGridViewTextBoxColumn,
            this.familyNameDataGridViewTextBoxColumn,
            this.adressDataGridViewTextBoxColumn,
            this.homeTelDataGridViewTextBoxColumn,
            this.cell1DataGridViewTextBoxColumn,
            this.cell2DataGridViewTextBoxColumn,
            this.email1DataGridViewTextBoxColumn,
            this.email2DataGridViewTextBoxColumn,
            this.sendnewsLetterDataGridViewTextBoxColumn,
            this.lastEditeddatedDataGridViewTextBoxColumn});
            this.familiesDataGridView.DataSource = this.familiesBindingSource;
            this.familiesDataGridView.Location = new System.Drawing.Point(12, 104);
            this.familiesDataGridView.Name = "familiesDataGridView";
            this.familiesDataGridView.ReadOnly = true;
            this.familiesDataGridView.RowHeadersVisible = false;
            this.familiesDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.familiesDataGridView.Size = new System.Drawing.Size(213, 408);
            this.familiesDataGridView.TabIndex = 25;
            // 
            // familyIDDataGridViewTextBoxColumn
            // 
            this.familyIDDataGridViewTextBoxColumn.DataPropertyName = "familyID";
            this.familyIDDataGridViewTextBoxColumn.HeaderText = "familyID";
            this.familyIDDataGridViewTextBoxColumn.Name = "familyIDDataGridViewTextBoxColumn";
            this.familyIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.familyIDDataGridViewTextBoxColumn.Width = 40;
            // 
            // familyNameDataGridViewTextBoxColumn
            // 
            this.familyNameDataGridViewTextBoxColumn.DataPropertyName = "familyName";
            this.familyNameDataGridViewTextBoxColumn.HeaderText = "familyName";
            this.familyNameDataGridViewTextBoxColumn.Name = "familyNameDataGridViewTextBoxColumn";
            this.familyNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.familyNameDataGridViewTextBoxColumn.Width = 80;
            // 
            // adressDataGridViewTextBoxColumn
            // 
            this.adressDataGridViewTextBoxColumn.DataPropertyName = "Adress";
            this.adressDataGridViewTextBoxColumn.HeaderText = "Adress";
            this.adressDataGridViewTextBoxColumn.Name = "adressDataGridViewTextBoxColumn";
            this.adressDataGridViewTextBoxColumn.ReadOnly = true;
            this.adressDataGridViewTextBoxColumn.Visible = false;
            // 
            // homeTelDataGridViewTextBoxColumn
            // 
            this.homeTelDataGridViewTextBoxColumn.DataPropertyName = "homeTel";
            this.homeTelDataGridViewTextBoxColumn.HeaderText = "homeTel";
            this.homeTelDataGridViewTextBoxColumn.Name = "homeTelDataGridViewTextBoxColumn";
            this.homeTelDataGridViewTextBoxColumn.ReadOnly = true;
            this.homeTelDataGridViewTextBoxColumn.Visible = false;
            // 
            // cell1DataGridViewTextBoxColumn
            // 
            this.cell1DataGridViewTextBoxColumn.DataPropertyName = "cell1";
            this.cell1DataGridViewTextBoxColumn.HeaderText = "cell1";
            this.cell1DataGridViewTextBoxColumn.Name = "cell1DataGridViewTextBoxColumn";
            this.cell1DataGridViewTextBoxColumn.ReadOnly = true;
            this.cell1DataGridViewTextBoxColumn.Visible = false;
            // 
            // cell2DataGridViewTextBoxColumn
            // 
            this.cell2DataGridViewTextBoxColumn.DataPropertyName = "cell2";
            this.cell2DataGridViewTextBoxColumn.HeaderText = "cell2";
            this.cell2DataGridViewTextBoxColumn.Name = "cell2DataGridViewTextBoxColumn";
            this.cell2DataGridViewTextBoxColumn.ReadOnly = true;
            this.cell2DataGridViewTextBoxColumn.Visible = false;
            // 
            // email1DataGridViewTextBoxColumn
            // 
            this.email1DataGridViewTextBoxColumn.DataPropertyName = "email1";
            this.email1DataGridViewTextBoxColumn.HeaderText = "email1";
            this.email1DataGridViewTextBoxColumn.Name = "email1DataGridViewTextBoxColumn";
            this.email1DataGridViewTextBoxColumn.ReadOnly = true;
            this.email1DataGridViewTextBoxColumn.Visible = false;
            // 
            // email2DataGridViewTextBoxColumn
            // 
            this.email2DataGridViewTextBoxColumn.DataPropertyName = "email2";
            this.email2DataGridViewTextBoxColumn.HeaderText = "email2";
            this.email2DataGridViewTextBoxColumn.Name = "email2DataGridViewTextBoxColumn";
            this.email2DataGridViewTextBoxColumn.ReadOnly = true;
            this.email2DataGridViewTextBoxColumn.Visible = false;
            // 
            // sendnewsLetterDataGridViewTextBoxColumn
            // 
            this.sendnewsLetterDataGridViewTextBoxColumn.DataPropertyName = "sendnewsLetter";
            this.sendnewsLetterDataGridViewTextBoxColumn.HeaderText = "sendnewsLetter";
            this.sendnewsLetterDataGridViewTextBoxColumn.Name = "sendnewsLetterDataGridViewTextBoxColumn";
            this.sendnewsLetterDataGridViewTextBoxColumn.ReadOnly = true;
            this.sendnewsLetterDataGridViewTextBoxColumn.Visible = false;
            // 
            // lastEditeddatedDataGridViewTextBoxColumn
            // 
            this.lastEditeddatedDataGridViewTextBoxColumn.DataPropertyName = "lastEditeddated";
            this.lastEditeddatedDataGridViewTextBoxColumn.HeaderText = "lastEditeddated";
            this.lastEditeddatedDataGridViewTextBoxColumn.Name = "lastEditeddatedDataGridViewTextBoxColumn";
            this.lastEditeddatedDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // familiesBindingSource
            // 
            this.familiesBindingSource.DataMember = "families";
            this.familiesBindingSource.DataSource = this.wrsMembersDataSet;
            // 
            // wrsMembersDataSet
            // 
            this.wrsMembersDataSet.DataSetName = "wrsMembersDataSet";
            this.wrsMembersDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(19, 19);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(35, 13);
            this.NameLabel.TabIndex = 17;
            this.NameLabel.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(198, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Contact Number";
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(67, 12);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(120, 20);
            this.NameTextBox.TabIndex = 13;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(288, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 12;
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(77, 48);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(59, 50);
            this.editButton.TabIndex = 10;
            this.editButton.Text = "Edit Family";
            this.editButton.UseVisualStyleBackColor = true;
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(142, 48);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(59, 50);
            this.deleteButton.TabIndex = 9;
            this.deleteButton.Text = "Delete Family";
            this.deleteButton.UseVisualStyleBackColor = true;
            // 
            // familyMembersSaveBTN
            // 
            this.familyMembersSaveBTN.Location = new System.Drawing.Point(454, 464);
            this.familyMembersSaveBTN.Name = "familyMembersSaveBTN";
            this.familyMembersSaveBTN.Size = new System.Drawing.Size(81, 23);
            this.familyMembersSaveBTN.TabIndex = 8;
            this.familyMembersSaveBTN.Text = "Save";
            this.familyMembersSaveBTN.UseVisualStyleBackColor = true;
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(55, 534);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(75, 23);
            this.BackButton.TabIndex = 27;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // searchFamilyBTN
            // 
            this.searchFamilyBTN.Location = new System.Drawing.Point(421, 9);
            this.searchFamilyBTN.Name = "searchFamilyBTN";
            this.searchFamilyBTN.Size = new System.Drawing.Size(137, 23);
            this.searchFamilyBTN.TabIndex = 11;
            this.searchFamilyBTN.Text = "Search Families";
            this.searchFamilyBTN.UseVisualStyleBackColor = true;
            // 
            // AddButton
            // 
            this.AddButton.Location = new System.Drawing.Point(12, 48);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(59, 50);
            this.AddButton.TabIndex = 8;
            this.AddButton.Text = "Add Family";
            this.AddButton.UseVisualStyleBackColor = true;
            // 
            // familyEventsSaveBTN
            // 
            this.familyEventsSaveBTN.Location = new System.Drawing.Point(454, 464);
            this.familyEventsSaveBTN.Name = "familyEventsSaveBTN";
            this.familyEventsSaveBTN.Size = new System.Drawing.Size(81, 23);
            this.familyEventsSaveBTN.TabIndex = 29;
            this.familyEventsSaveBTN.Text = "Save";
            this.familyEventsSaveBTN.UseVisualStyleBackColor = true;
            this.familyEventsSaveBTN.Visible = false;
            // 
            // FamiliesTabControl
            // 
            this.FamiliesTabControl.Controls.Add(this.FamilyDetailsTabPage);
            this.FamiliesTabControl.Controls.Add(this.familyMemberstabPage);
            this.FamiliesTabControl.Controls.Add(this.FamilyEventsTabPage);
            this.FamiliesTabControl.Location = new System.Drawing.Point(231, 38);
            this.FamiliesTabControl.Name = "FamiliesTabControl";
            this.FamiliesTabControl.SelectedIndex = 0;
            this.FamiliesTabControl.Size = new System.Drawing.Size(549, 519);
            this.FamiliesTabControl.TabIndex = 32;
            // 
            // FamilyDetailsTabPage
            // 
            this.FamilyDetailsTabPage.Controls.Add(this.familyAddressRichTextBox);
            this.FamilyDetailsTabPage.Controls.Add(this.HomeTelLable);
            this.FamilyDetailsTabPage.Controls.Add(this.MeritalSCheckedListBox);
            this.FamilyDetailsTabPage.Controls.Add(this.DOBNonApplicableCHKB);
            this.FamilyDetailsTabPage.Controls.Add(this.lastEditedDateTimePicker);
            this.FamilyDetailsTabPage.Controls.Add(this.Cell1Label);
            this.FamilyDetailsTabPage.Controls.Add(this.familyAddressLabel);
            this.FamilyDetailsTabPage.Controls.Add(this.DOBLabel);
            this.FamilyDetailsTabPage.Controls.Add(this.email2Lable);
            this.FamilyDetailsTabPage.Controls.Add(this.EmailLabel);
            this.FamilyDetailsTabPage.Controls.Add(this.Cell2Lable);
            this.FamilyDetailsTabPage.Controls.Add(this.familyNameLabel);
            this.FamilyDetailsTabPage.Controls.Add(this.HomeTelTextBox);
            this.FamilyDetailsTabPage.Controls.Add(this.Email2TextBox);
            this.FamilyDetailsTabPage.Controls.Add(this.Email1TextBox);
            this.FamilyDetailsTabPage.Controls.Add(this.Cell2TextBox);
            this.FamilyDetailsTabPage.Controls.Add(this.Cell1textBox);
            this.FamilyDetailsTabPage.Controls.Add(this.textBox2);
            this.FamilyDetailsTabPage.Controls.Add(this.familyNameTextBox);
            this.FamilyDetailsTabPage.Controls.Add(this.familyDetailsSaveBTN);
            this.FamilyDetailsTabPage.Location = new System.Drawing.Point(4, 22);
            this.FamilyDetailsTabPage.Name = "FamilyDetailsTabPage";
            this.FamilyDetailsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.FamilyDetailsTabPage.Size = new System.Drawing.Size(541, 493);
            this.FamilyDetailsTabPage.TabIndex = 0;
            this.FamilyDetailsTabPage.Text = "Family Details";
            this.FamilyDetailsTabPage.UseVisualStyleBackColor = true;
            // 
            // familyAddressRichTextBox
            // 
            this.familyAddressRichTextBox.Location = new System.Drawing.Point(103, 53);
            this.familyAddressRichTextBox.Name = "familyAddressRichTextBox";
            this.familyAddressRichTextBox.Size = new System.Drawing.Size(304, 122);
            this.familyAddressRichTextBox.TabIndex = 37;
            this.familyAddressRichTextBox.Text = "";
            // 
            // HomeTelLable
            // 
            this.HomeTelLable.AutoSize = true;
            this.HomeTelLable.Location = new System.Drawing.Point(21, 184);
            this.HomeTelLable.Name = "HomeTelLable";
            this.HomeTelLable.Size = new System.Drawing.Size(49, 13);
            this.HomeTelLable.TabIndex = 36;
            this.HomeTelLable.Text = "Home tel";
            // 
            // MeritalSCheckedListBox
            // 
            this.MeritalSCheckedListBox.Enabled = false;
            this.MeritalSCheckedListBox.FormattingEnabled = true;
            this.MeritalSCheckedListBox.Items.AddRange(new object[] {
            "married",
            "single"});
            this.MeritalSCheckedListBox.Location = new System.Drawing.Point(297, 231);
            this.MeritalSCheckedListBox.Name = "MeritalSCheckedListBox";
            this.MeritalSCheckedListBox.Size = new System.Drawing.Size(121, 34);
            this.MeritalSCheckedListBox.TabIndex = 28;
            // 
            // DOBNonApplicableCHKB
            // 
            this.DOBNonApplicableCHKB.AutoSize = true;
            this.DOBNonApplicableCHKB.Enabled = false;
            this.DOBNonApplicableCHKB.Location = new System.Drawing.Point(311, 337);
            this.DOBNonApplicableCHKB.Name = "DOBNonApplicableCHKB";
            this.DOBNonApplicableCHKB.Size = new System.Drawing.Size(107, 17);
            this.DOBNonApplicableCHKB.TabIndex = 30;
            this.DOBNonApplicableCHKB.Text = "Send Newsletter:";
            this.DOBNonApplicableCHKB.UseVisualStyleBackColor = true;
            // 
            // lastEditedDateTimePicker
            // 
            this.lastEditedDateTimePicker.CustomFormat = "dd/MM/yyyy";
            this.lastEditedDateTimePicker.Enabled = false;
            this.lastEditedDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.lastEditedDateTimePicker.Location = new System.Drawing.Point(122, 432);
            this.lastEditedDateTimePicker.MaxDate = new System.DateTime(2116, 1, 1, 0, 0, 0, 0);
            this.lastEditedDateTimePicker.MinDate = new System.DateTime(1930, 1, 1, 0, 0, 0, 0);
            this.lastEditedDateTimePicker.Name = "lastEditedDateTimePicker";
            this.lastEditedDateTimePicker.Size = new System.Drawing.Size(121, 20);
            this.lastEditedDateTimePicker.TabIndex = 29;
            this.lastEditedDateTimePicker.Value = new System.DateTime(2016, 4, 11, 0, 0, 0, 0);
            // 
            // Cell1Label
            // 
            this.Cell1Label.AutoSize = true;
            this.Cell1Label.Location = new System.Drawing.Point(21, 224);
            this.Cell1Label.Name = "Cell1Label";
            this.Cell1Label.Size = new System.Drawing.Size(45, 13);
            this.Cell1Label.TabIndex = 31;
            this.Cell1Label.Text = "Cell no1";
            // 
            // familyAddressLabel
            // 
            this.familyAddressLabel.AutoSize = true;
            this.familyAddressLabel.Location = new System.Drawing.Point(17, 53);
            this.familyAddressLabel.Name = "familyAddressLabel";
            this.familyAddressLabel.Size = new System.Drawing.Size(39, 13);
            this.familyAddressLabel.TabIndex = 32;
            this.familyAddressLabel.Text = "Adress";
            // 
            // DOBLabel
            // 
            this.DOBLabel.AutoSize = true;
            this.DOBLabel.Location = new System.Drawing.Point(21, 439);
            this.DOBLabel.Name = "DOBLabel";
            this.DOBLabel.Size = new System.Drawing.Size(60, 13);
            this.DOBLabel.TabIndex = 33;
            this.DOBLabel.Text = "Last Edited";
            // 
            // email2Lable
            // 
            this.email2Lable.AutoSize = true;
            this.email2Lable.Location = new System.Drawing.Point(21, 368);
            this.email2Lable.Name = "email2Lable";
            this.email2Lable.Size = new System.Drawing.Size(41, 13);
            this.email2Lable.TabIndex = 34;
            this.email2Lable.Text = "Email 2";
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Location = new System.Drawing.Point(21, 325);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(32, 13);
            this.EmailLabel.TabIndex = 34;
            this.EmailLabel.Text = "Email";
            // 
            // Cell2Lable
            // 
            this.Cell2Lable.AutoSize = true;
            this.Cell2Lable.Location = new System.Drawing.Point(21, 278);
            this.Cell2Lable.Name = "Cell2Lable";
            this.Cell2Lable.Size = new System.Drawing.Size(45, 13);
            this.Cell2Lable.TabIndex = 34;
            this.Cell2Lable.Text = "Cell no2";
            // 
            // familyNameLabel
            // 
            this.familyNameLabel.AutoSize = true;
            this.familyNameLabel.Location = new System.Drawing.Point(21, 13);
            this.familyNameLabel.Name = "familyNameLabel";
            this.familyNameLabel.Size = new System.Drawing.Size(35, 13);
            this.familyNameLabel.TabIndex = 35;
            this.familyNameLabel.Text = "Name";
            // 
            // HomeTelTextBox
            // 
            this.HomeTelTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.HomeTelTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.HomeTelTextBox.Enabled = false;
            this.HomeTelTextBox.Location = new System.Drawing.Point(103, 181);
            this.HomeTelTextBox.Name = "HomeTelTextBox";
            this.HomeTelTextBox.Size = new System.Drawing.Size(121, 20);
            this.HomeTelTextBox.TabIndex = 25;
            // 
            // Email2TextBox
            // 
            this.Email2TextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Email2TextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.Email2TextBox.Enabled = false;
            this.Email2TextBox.Location = new System.Drawing.Point(103, 358);
            this.Email2TextBox.Name = "Email2TextBox";
            this.Email2TextBox.Size = new System.Drawing.Size(121, 20);
            this.Email2TextBox.TabIndex = 25;
            // 
            // Email1TextBox
            // 
            this.Email1TextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Email1TextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.Email1TextBox.Enabled = false;
            this.Email1TextBox.Location = new System.Drawing.Point(103, 315);
            this.Email1TextBox.Name = "Email1TextBox";
            this.Email1TextBox.Size = new System.Drawing.Size(121, 20);
            this.Email1TextBox.TabIndex = 25;
            // 
            // Cell2TextBox
            // 
            this.Cell2TextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Cell2TextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.Cell2TextBox.Enabled = false;
            this.Cell2TextBox.Location = new System.Drawing.Point(103, 268);
            this.Cell2TextBox.Name = "Cell2TextBox";
            this.Cell2TextBox.Size = new System.Drawing.Size(121, 20);
            this.Cell2TextBox.TabIndex = 25;
            // 
            // Cell1textBox
            // 
            this.Cell1textBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Cell1textBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.Cell1textBox.Enabled = false;
            this.Cell1textBox.Location = new System.Drawing.Point(103, 221);
            this.Cell1textBox.Name = "Cell1textBox";
            this.Cell1textBox.Size = new System.Drawing.Size(121, 20);
            this.Cell1textBox.TabIndex = 25;
            // 
            // textBox2
            // 
            this.textBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.textBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(286, 205);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(121, 20);
            this.textBox2.TabIndex = 25;
            // 
            // familyNameTextBox
            // 
            this.familyNameTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.familyNameTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.familyNameTextBox.Enabled = false;
            this.familyNameTextBox.Location = new System.Drawing.Point(103, 6);
            this.familyNameTextBox.Name = "familyNameTextBox";
            this.familyNameTextBox.Size = new System.Drawing.Size(121, 20);
            this.familyNameTextBox.TabIndex = 24;
            // 
            // familyDetailsSaveBTN
            // 
            this.familyDetailsSaveBTN.Location = new System.Drawing.Point(460, 464);
            this.familyDetailsSaveBTN.Name = "familyDetailsSaveBTN";
            this.familyDetailsSaveBTN.Size = new System.Drawing.Size(75, 23);
            this.familyDetailsSaveBTN.TabIndex = 23;
            this.familyDetailsSaveBTN.Text = "Save";
            this.familyDetailsSaveBTN.UseVisualStyleBackColor = true;
            this.familyDetailsSaveBTN.Visible = false;
            // 
            // familyMemberstabPage
            // 
            this.familyMemberstabPage.Controls.Add(this.familyMembersDataGridView);
            this.familyMemberstabPage.Controls.Add(this.familyMembersSaveBTN);
            this.familyMemberstabPage.Controls.Add(this.AddNewMemberButton);
            this.familyMemberstabPage.Location = new System.Drawing.Point(4, 22);
            this.familyMemberstabPage.Name = "familyMemberstabPage";
            this.familyMemberstabPage.Padding = new System.Windows.Forms.Padding(3);
            this.familyMemberstabPage.Size = new System.Drawing.Size(541, 493);
            this.familyMemberstabPage.TabIndex = 1;
            this.familyMemberstabPage.Text = "Family Members";
            this.familyMemberstabPage.UseVisualStyleBackColor = true;
            // 
            // familyMembersDataGridView
            // 
            this.familyMembersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.familyMembersDataGridView.Location = new System.Drawing.Point(16, 42);
            this.familyMembersDataGridView.Name = "familyMembersDataGridView";
            this.familyMembersDataGridView.Size = new System.Drawing.Size(519, 408);
            this.familyMembersDataGridView.TabIndex = 26;
            // 
            // AddNewMemberButton
            // 
            this.AddNewMemberButton.Location = new System.Drawing.Point(16, 6);
            this.AddNewMemberButton.Name = "AddNewMemberButton";
            this.AddNewMemberButton.Size = new System.Drawing.Size(519, 23);
            this.AddNewMemberButton.TabIndex = 8;
            this.AddNewMemberButton.Text = "Add";
            this.AddNewMemberButton.UseVisualStyleBackColor = true;
            // 
            // FamilyEventsTabPage
            // 
            this.FamilyEventsTabPage.Controls.Add(this.familyEventsDataGridView);
            this.FamilyEventsTabPage.Controls.Add(this.MapsButton);
            this.FamilyEventsTabPage.Controls.Add(this.familyEventsSaveBTN);
            this.FamilyEventsTabPage.Controls.Add(this.EventDetailsRichTextBox);
            this.FamilyEventsTabPage.Controls.Add(this.richTextBox1);
            this.FamilyEventsTabPage.Controls.Add(this.FamilyContactPersonLabel);
            this.FamilyEventsTabPage.Controls.Add(this.EventDetailsLabel);
            this.FamilyEventsTabPage.Controls.Add(this.FamilyContactPersonTelLabel);
            this.FamilyEventsTabPage.Controls.Add(this.eventAdressLabel);
            this.FamilyEventsTabPage.Controls.Add(this.eventNameLabel);
            this.FamilyEventsTabPage.Controls.Add(this.FamilyContactPersonTextBox);
            this.FamilyEventsTabPage.Controls.Add(this.FamilyContactPersonTelTextBox);
            this.FamilyEventsTabPage.Controls.Add(this.eventNameTextBox);
            this.FamilyEventsTabPage.Location = new System.Drawing.Point(4, 22);
            this.FamilyEventsTabPage.Name = "FamilyEventsTabPage";
            this.FamilyEventsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.FamilyEventsTabPage.Size = new System.Drawing.Size(541, 493);
            this.FamilyEventsTabPage.TabIndex = 2;
            this.FamilyEventsTabPage.Text = "Family Events";
            this.FamilyEventsTabPage.UseVisualStyleBackColor = true;
            // 
            // familyEventsDataGridView
            // 
            this.familyEventsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.familyEventsDataGridView.Location = new System.Drawing.Point(6, 6);
            this.familyEventsDataGridView.Name = "familyEventsDataGridView";
            this.familyEventsDataGridView.Size = new System.Drawing.Size(137, 481);
            this.familyEventsDataGridView.TabIndex = 48;
            // 
            // MapsButton
            // 
            this.MapsButton.Location = new System.Drawing.Point(457, 69);
            this.MapsButton.Name = "MapsButton";
            this.MapsButton.Size = new System.Drawing.Size(75, 107);
            this.MapsButton.TabIndex = 47;
            this.MapsButton.Text = "Maps";
            this.MapsButton.UseVisualStyleBackColor = true;
            this.MapsButton.Visible = false;
            // 
            // EventDetailsRichTextBox
            // 
            this.EventDetailsRichTextBox.Location = new System.Drawing.Point(250, 207);
            this.EventDetailsRichTextBox.Name = "EventDetailsRichTextBox";
            this.EventDetailsRichTextBox.Size = new System.Drawing.Size(282, 122);
            this.EventDetailsRichTextBox.TabIndex = 46;
            this.EventDetailsRichTextBox.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(250, 69);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(201, 107);
            this.richTextBox1.TabIndex = 46;
            this.richTextBox1.Text = "";
            // 
            // FamilyContactPersonLabel
            // 
            this.FamilyContactPersonLabel.AutoSize = true;
            this.FamilyContactPersonLabel.Location = new System.Drawing.Point(167, 364);
            this.FamilyContactPersonLabel.Name = "FamilyContactPersonLabel";
            this.FamilyContactPersonLabel.Size = new System.Drawing.Size(112, 13);
            this.FamilyContactPersonLabel.TabIndex = 45;
            this.FamilyContactPersonLabel.Text = "Family Contact Person";
            // 
            // EventDetailsLabel
            // 
            this.EventDetailsLabel.AutoSize = true;
            this.EventDetailsLabel.Location = new System.Drawing.Point(167, 262);
            this.EventDetailsLabel.Name = "EventDetailsLabel";
            this.EventDetailsLabel.Size = new System.Drawing.Size(70, 13);
            this.EventDetailsLabel.TabIndex = 43;
            this.EventDetailsLabel.Text = "Event Details";
            // 
            // FamilyContactPersonTelLabel
            // 
            this.FamilyContactPersonTelLabel.AutoSize = true;
            this.FamilyContactPersonTelLabel.Location = new System.Drawing.Point(167, 415);
            this.FamilyContactPersonTelLabel.Name = "FamilyContactPersonTelLabel";
            this.FamilyContactPersonTelLabel.Size = new System.Drawing.Size(84, 13);
            this.FamilyContactPersonTelLabel.TabIndex = 42;
            this.FamilyContactPersonTelLabel.Text = "Contact Number";
            // 
            // eventAdressLabel
            // 
            this.eventAdressLabel.AutoSize = true;
            this.eventAdressLabel.Location = new System.Drawing.Point(167, 116);
            this.eventAdressLabel.Name = "eventAdressLabel";
            this.eventAdressLabel.Size = new System.Drawing.Size(70, 13);
            this.eventAdressLabel.TabIndex = 43;
            this.eventAdressLabel.Text = "Event Adress";
            // 
            // eventNameLabel
            // 
            this.eventNameLabel.AutoSize = true;
            this.eventNameLabel.Location = new System.Drawing.Point(167, 22);
            this.eventNameLabel.Name = "eventNameLabel";
            this.eventNameLabel.Size = new System.Drawing.Size(66, 13);
            this.eventNameLabel.TabIndex = 44;
            this.eventNameLabel.Text = "Event Name";
            // 
            // FamilyContactPersonTextBox
            // 
            this.FamilyContactPersonTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.FamilyContactPersonTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.FamilyContactPersonTextBox.Enabled = false;
            this.FamilyContactPersonTextBox.Location = new System.Drawing.Point(286, 360);
            this.FamilyContactPersonTextBox.Name = "FamilyContactPersonTextBox";
            this.FamilyContactPersonTextBox.Size = new System.Drawing.Size(121, 20);
            this.FamilyContactPersonTextBox.TabIndex = 39;
            // 
            // FamilyContactPersonTelTextBox
            // 
            this.FamilyContactPersonTelTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.FamilyContactPersonTelTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.FamilyContactPersonTelTextBox.Enabled = false;
            this.FamilyContactPersonTelTextBox.Location = new System.Drawing.Point(286, 411);
            this.FamilyContactPersonTelTextBox.Name = "FamilyContactPersonTelTextBox";
            this.FamilyContactPersonTelTextBox.Size = new System.Drawing.Size(121, 20);
            this.FamilyContactPersonTelTextBox.TabIndex = 40;
            // 
            // eventNameTextBox
            // 
            this.eventNameTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.eventNameTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.eventNameTextBox.Enabled = false;
            this.eventNameTextBox.Location = new System.Drawing.Point(250, 18);
            this.eventNameTextBox.Name = "eventNameTextBox";
            this.eventNameTextBox.Size = new System.Drawing.Size(121, 20);
            this.eventNameTextBox.TabIndex = 38;
            // 
            // familiesTableAdapter
            // 
            this.familiesTableAdapter.ClearBeforeFill = true;
            // 
            // Families
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 569);
            this.Controls.Add(this.FamiliesTabControl);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.familiesDataGridView);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.NameTextBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.searchFamilyBTN);
            this.Controls.Add(this.AddButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Families";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Families";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Families_FormClosed);
            this.Load += new System.EventHandler(this.Families_Load);
            ((System.ComponentModel.ISupportInitialize)(this.familiesDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.familiesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrsMembersDataSet)).EndInit();
            this.FamiliesTabControl.ResumeLayout(false);
            this.FamilyDetailsTabPage.ResumeLayout(false);
            this.FamilyDetailsTabPage.PerformLayout();
            this.familyMemberstabPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.familyMembersDataGridView)).EndInit();
            this.FamilyEventsTabPage.ResumeLayout(false);
            this.FamilyEventsTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.familyEventsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView familiesDataGridView;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button familyMembersSaveBTN;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button searchFamilyBTN;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Button familyEventsSaveBTN;
        private System.Windows.Forms.TabControl FamiliesTabControl;
        private System.Windows.Forms.TabPage FamilyDetailsTabPage;
        private System.Windows.Forms.TabPage familyMemberstabPage;
        private System.Windows.Forms.RichTextBox familyAddressRichTextBox;
        private System.Windows.Forms.Label HomeTelLable;
        private System.Windows.Forms.CheckedListBox MeritalSCheckedListBox;
        private System.Windows.Forms.CheckBox DOBNonApplicableCHKB;
        private System.Windows.Forms.DateTimePicker lastEditedDateTimePicker;
        private System.Windows.Forms.Label Cell1Label;
        private System.Windows.Forms.Label familyAddressLabel;
        private System.Windows.Forms.Label DOBLabel;
        private System.Windows.Forms.Label email2Lable;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.Label Cell2Lable;
        private System.Windows.Forms.Label familyNameLabel;
        private System.Windows.Forms.TextBox HomeTelTextBox;
        private System.Windows.Forms.TextBox Email2TextBox;
        private System.Windows.Forms.TextBox Email1TextBox;
        private System.Windows.Forms.TextBox Cell2TextBox;
        private System.Windows.Forms.TextBox Cell1textBox;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox familyNameTextBox;
        private System.Windows.Forms.Button familyDetailsSaveBTN;
        private System.Windows.Forms.TabPage FamilyEventsTabPage;
        private System.Windows.Forms.DataGridView familyEventsDataGridView;
        private System.Windows.Forms.Button MapsButton;
        private System.Windows.Forms.RichTextBox EventDetailsRichTextBox;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label FamilyContactPersonLabel;
        private System.Windows.Forms.Label EventDetailsLabel;
        private System.Windows.Forms.Label FamilyContactPersonTelLabel;
        private System.Windows.Forms.Label eventAdressLabel;
        private System.Windows.Forms.Label eventNameLabel;
        private System.Windows.Forms.TextBox FamilyContactPersonTextBox;
        private System.Windows.Forms.TextBox FamilyContactPersonTelTextBox;
        private System.Windows.Forms.TextBox eventNameTextBox;
        private System.Windows.Forms.DataGridView familyMembersDataGridView;
        private System.Windows.Forms.Button AddNewMemberButton;
        private wrsMembersDataSet wrsMembersDataSet;
        private System.Windows.Forms.BindingSource familiesBindingSource;
        private wrsMembersDataSetTableAdapters.familiesTableAdapter familiesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn familyIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn familyNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn homeTelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cell1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cell2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn email1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn email2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sendnewsLetterDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastEditeddatedDataGridViewTextBoxColumn;
    }
}