﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using wrs_management.wrsMembersDataSetTableAdapters;

namespace wrs_management
{
    public partial class members : Form
    {
        
        memberDetailsTableAdapter detailsDS = new memberDetailsTableAdapter();
        familiesTableAdapter familiesDS = new familiesTableAdapter();
        FamilyMemberTableAdapter familyMembershipDS = new FamilyMemberTableAdapter();
        GroupsFunctionTableAdapter groupFunctionsDS = new GroupsFunctionTableAdapter();
        memberGroupTableAdapter groupMembersDS = new memberGroupTableAdapter();


        int selectedMemberID, selectedgroupID = -1;
        string clickedButton = "";
        int famID;
        public members()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            new dashboard().Show();
            this.Hide();
            
        }

        private void familyBTN_Click(object sender, EventArgs e)
        {
            new Families().ShowDialog();
            
        }

        
        private void enableControlls() 
        { 
             foreach (Control c in Details.Controls)
            {
                c.Enabled = true;
                familyBTN.Visible = detailsSaveButton.Visible = cancelButton.Visible = true;
                addButton.Enabled = editButton.Enabled = deleteButton.Enabled = false;
                
            }
             foreach (Control c in GroupFunction.Controls)
             {
                 c.Enabled = true;
                 taskSaveButton.Visible = true;
                 addButton.Enabled = editButton.Enabled = deleteButton.Enabled = false;
             }
                         

             foreach (Control c in TaskAssignments.Controls)
             {
                 c.Enabled = true;
                 taskAssignmentsSaveButton.Visible = true;
                 addButton.Enabled = editButton.Enabled = deleteButton.Enabled = false;
                 
             }



        }


        private void disableControls()
        {
            foreach (Control c in Details.Controls)
            {
                if (c is Label) { }
                else
                {

                    c.Enabled = false;
                    familyBTN.Visible = detailsSaveButton.Visible = cancelButton.Visible = false;
                    detailsSaveButton.Text = "Save";
                    addButton.Enabled = editButton.Enabled = deleteButton.Enabled = true;
                    clearControls();
                }
            }

            foreach (Control c in GroupFunction.Controls)
            {
                if (c is Label) { }
                else
                {

                
                c.Enabled = false;
                taskSaveButton.Visible = false;
                addButton.Enabled = editButton.Enabled = deleteButton.Enabled = true;
                clearControls();
                }
            }

            foreach (Control c in TaskAssignments.Controls)
            {
                if (c is Label) { }
                else
                {
                    c.Enabled = false;
                    taskSaveButton.Visible = false;
                    addButton.Enabled = editButton.Enabled = deleteButton.Enabled = true;
                    clearControls();
                }
            }


            foreach (Control c in keepIntouch.Controls)
            {
                if (c is Label) { }
                else
                {
                    c.Enabled = false;
                    taskSaveButton.Visible = false;
                    addButton.Enabled = editButton.Enabled = deleteButton.Enabled = true;
                    clearControls();
                }


            }
        }


        private void clearControls()
        {
            foreach (Control c in Details.Controls)
            {
                if (c is Label||c is Button|| c is CheckBox)
                {
                    DOBNonApplicableCHKB.Checked = false;

                }
                else
                {
                    c.Text = "";
                    genderComboBox.SelectedItem = MembershipComboBox.SelectedItem = null;
                    MeritalSCheckedListBox.SetItemChecked(0, false);
                    MeritalSCheckedListBox.SetItemChecked(1, false);
                    DOBDateTimePicker.Value = DateTime.Now;
                }
            }

            foreach (Control c in GroupFunction.Controls)
             {
                if (c is Label||c is Button|| c is CheckBox)
                {
                   

                }
                else
                {
                    c.Text = "";
                    groupsFunctionRolesComboBox.SelectedItem = null;
                    foundationDateDateTimePicker.Value = DateTime.Now;
                }
            }

            foreach (Control c in TaskAssignments.Controls)
            {
                if (c is Label||c is Button|| c is CheckBox)
                {
                   

                }
                else
                {
                    c.Text = "";
                    taskAssignmentsStatusComboBox.SelectedItem = null;
                    taskAssignmentsStartDateTimePicker.Value = taskAssignmentsDueDateTimePicker.Value = DateTime.Now;
                }
           }

            foreach (Control c in keepIntouch.Controls)
            {
                if (c is Label||c is Button|| c is CheckBox)
                {
                   

                }
                else
                {
                    c.Text = "";
                    taskAssignmentsStatusComboBox.SelectedItem = null;
                    taskAssignmentsStartDateTimePicker.Value = taskAssignmentsDueDateTimePicker.Value = DateTime.Now;
                }
           }

            famID = selectedMemberID = -1;
            clickedButton = "";

                    
        }


        private void detailsSaveButton_Click(object sender, EventArgs e)
        {   
            
            if (clickedButton == "AddBTN")
            {
                string DTnow = DateTime.Now.ToString();
                string surn = SurnameComboBox.Text;

                int familyIDadd = Convert.ToInt16(familiesDS.InsertFamily1(surn, DTnow));

               
                detailsDS.InsertMember(NameTextBox.Text,familyIDadd, genderComboBox.SelectedItem.ToString(), MembershipComboBox.SelectedItem.ToString(), MeritalSCheckedListBox.SelectedItem.ToString(), DOBDateTimePicker.Value, AdressRichTextBox.Text,contactNumberTextBox1.Text);
                
                
                disableControls();
                clearControls();
                members_Load(sender,e);

   
            }
            else
            {
                if (clickedButton == "editBTN" && selectedMemberID > -1)
                {
                    string meritalStatas;
                    if (MeritalSCheckedListBox.GetItemChecked(0))
                    {
                        meritalStatas = "married";
                    }
                    else
                    {
                        meritalStatas = "single";
                    }
                    //***********update member surname
                     
                    string DTnowupdate = DateTime.Now.ToString();
                    familiesDS.updateSurnameByID(SurnameComboBox.Text, DTnowupdate,famID);
                    
                    //************

                    detailsDS.UpdateMember(NameTextBox.Text,famID, genderComboBox.SelectedItem.ToString(), MembershipComboBox.SelectedItem.ToString(),meritalStatas,DOBDateTimePicker.Value, AdressRichTextBox.Text, contactNumberTextBox1.Text, selectedMemberID);


                    clearControls();
                    disableControls();
                    members_Load(sender, e);
                }
                else
                {
                    if (clickedButton == "deleteBTN" && selectedMemberID >-1)
                    {
                        detailsDS.DeleteMember(selectedMemberID);


                        clearControls();
                        disableControls();
                        members_Load(sender, e);
                    }
                }
            }
            
            

        }



        private void cancelButton_Click(object sender, EventArgs e)
        {
            clearControls();
            disableControls();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            
            clearControls();
            clickedButton = "AddBTN";
            enableControlls();
            for (int i = 0; i < familiesDS.GetData().Rows.Count; i++)
            {

            }
           // SurnameComboBox.Items.Add(familiesDS.GetData().c);
            
        }

        private void editButton_Click(object sender, EventArgs e)
        {
           enableControlls();
           clickedButton = "editBTN";
           
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            clickedButton = "deleteBTN";
            detailsSaveButton.Text = "Delete";
            enableControlls();
        }

       

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            clearControls();
            if (e.RowIndex >= 0)
                {
                    selRow(e.RowIndex);
                }
            
        }

        private void members_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }


        void selRow(int selIndex)
        {
            selectedMemberID = Convert.ToInt32(dataGridView1.Rows[selIndex].Cells[0].Value);
            //details
            NameTextBox.Text = dataGridView1.Rows[selIndex].Cells[1].Value.ToString();
            famID = Convert.ToInt16(dataGridView1.Rows[selIndex].Cells[2].Value);
           
            SurnameComboBox.Text = familiesDS.FillBy(famID).ToString();
            genderComboBox.SelectedItem = dataGridView1.Rows[selIndex].Cells[3].Value.ToString();
            MembershipComboBox.SelectedItem = dataGridView1.Rows[selIndex].Cells[4].Value.ToString();
            DOBDateTimePicker.Value = Convert.ToDateTime(dataGridView1.Rows[selIndex].Cells[6].Value);
            AdressRichTextBox.Text=dataGridView1.Rows[selIndex].Cells[7].Value.ToString(); 
            contactNumberTextBox1.Text = dataGridView1.Rows[selIndex].Cells[8].Value.ToString();

            if (dataGridView1.Rows[selIndex].Cells[5].Value.ToString() == "married")
            {
                MeritalSCheckedListBox.SetItemChecked(0, true);
            }
            else
            {
                MeritalSCheckedListBox.SetItemChecked(1, true);
            }
              


            ////GroupFunction
            dataGridView2.DataSource = groupMembersDS.GetGroupMembersByID(selectedMemberID);

// datagridview 2 selection


  
// datagridview 2 selection close










            //groupsFunctionNametextBox.Text =
            //groupsFunctionRolesComboBox.SelectedItem =
            //RoleDiscriptionRichTextBox.Text=
            //foundationDateDateTimePicker.Value =
            //groupDiscriptionRichTextBox.Text= 




            ////TaskAssignments
            //taskAssignmentsNameTextBox.Text =
            //taskAssignmentsStartDateTimePicker.Value =
            //taskAssignmentsDueDateTimePicker.Value =
            //taskAssignmentsRichTextBox.Text =
            //taskAssignmentsStatusComboBox.SelectedItem = 



            ////keepIntouch





            ////Notes
            //noteTittleTextBox.Text =
            //noteDateTimePicker.Value =
            //noteDiscriptionRichTextBox.Text = 




            ////


    }

        void selRowGroups(int selIndex)
        {
            selectedgroupID = Convert.ToInt32(dataGridView2.Rows[selIndex].Cells[0].Value);
            //details
            NameTextBox.Text = dataGridView2.Rows[selIndex].Cells[1].Value.ToString();
            famID = Convert.ToInt16(dataGridView2.Rows[selIndex].Cells[2].Value);

            SurnameComboBox.Text = familiesDS.FillBy(famID).ToString();
            genderComboBox.SelectedItem = dataGridView1.Rows[selIndex].Cells[3].Value.ToString();
            MembershipComboBox.SelectedItem = dataGridView1.Rows[selIndex].Cells[4].Value.ToString();
            DOBDateTimePicker.Value = Convert.ToDateTime(dataGridView1.Rows[selIndex].Cells[6].Value);
            AdressRichTextBox.Text = dataGridView1.Rows[selIndex].Cells[7].Value.ToString();
            contactNumberTextBox1.Text = dataGridView1.Rows[selIndex].Cells[8].Value.ToString();

            if (dataGridView1.Rows[selIndex].Cells[5].Value.ToString() == "married")
            {
                MeritalSCheckedListBox.SetItemChecked(0, true);
            }
            else
            {
                MeritalSCheckedListBox.SetItemChecked(1, true);
            }

        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            if (tabControl1.SelectedTab.Name == "details" )
            {
                
            }
            if (tabControl1.SelectedTab.Name == "GroupFunction")
            {

            }
            if (tabControl1.SelectedTab.Name == "TaskAssignments")
            {

            }
            if (tabControl1.SelectedTab.Name == "keepIntouch")
            {

            }
            if (tabControl1.SelectedTab.Name == "Notes")
            {

            }
        }

        private void members_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'wrsMembersDataSet.memberGroup' table. You can move, or remove it, as needed.
            this.memberGroupTableAdapter.Fill(this.wrsMembersDataSet.memberGroup);
            // TODO: This line of code loads data into the 'wrsMembersDataSet.GroupsFunction' table. You can move, or remove it, as needed.
           this.groupsFunctionTableAdapter.Fill(this.wrsMembersDataSet.GroupsFunction);
           this.familiesTableAdapter.Fill(this.wrsMembersDataSet.families);
           this.memberDetailsTableAdapter.Fill(this.wrsMembersDataSet.memberDetails);
            

        }

        private void Groups_FunctionsButton_Click(object sender, EventArgs e)
        {
            new GroupsAndFunctions(selectedMemberID).ShowDialog();
            this.Dispose();
        }

       

       
        
        }

        
    }
