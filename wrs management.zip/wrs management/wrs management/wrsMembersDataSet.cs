﻿namespace wrs_management {
    
    
    public partial class wrsMembersDataSet {
        partial class memberDetailsDataTable
        {
        }
    }
}

namespace wrs_management.wrsMembersDataSetTableAdapters {
    
    
    public partial class familiesTableAdapter {
    }
}
