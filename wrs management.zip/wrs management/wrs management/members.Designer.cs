﻿namespace wrs_management
{
    partial class members
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(members));
            this.BackButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.editButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.memberDetailsIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.membershipDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.meritalStatusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateOfBirthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wrsMembersDataSet = new wrs_management.wrsMembersDataSet();
            this.keepIntouch = new System.Windows.Forms.TabPage();
            this.MassegeLable = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.sendButton = new System.Windows.Forms.Button();
            this.TaskAssignments = new System.Windows.Forms.TabPage();
            this.taskAssignmentDataGridView = new System.Windows.Forms.DataGridView();
            this.groupFunctionIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.missionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupsFunctionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cancelButton3 = new System.Windows.Forms.Button();
            this.taskAssignmentsStatusComboBox = new System.Windows.Forms.ComboBox();
            this.taskAssignmentsDueDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.taskAssignmentsStartDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.taskAssignmentsRichTextBox = new System.Windows.Forms.RichTextBox();
            this.taskAssignmentsNameTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tasksButton = new System.Windows.Forms.Button();
            this.taskAssignmentsSaveButton = new System.Windows.Forms.Button();
            this.GroupFunction = new System.Windows.Forms.TabPage();
            this.groupsFunctionTypecomboBox = new System.Windows.Forms.ComboBox();
            this.groupsFunctionTypelabel = new System.Windows.Forms.Label();
            this.groupsFunctionsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mission = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupsFunctionBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.memberGroupIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberDetailsIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupFunctionIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberFunctionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.functionDiscriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memberGroupBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.GFCancelButton = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupsFunctionRolesComboBox = new System.Windows.Forms.ComboBox();
            this.foundationDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.RoleDiscriptionRichTextBox = new System.Windows.Forms.RichTextBox();
            this.groupDiscriptionRichTextBox = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.foundationDateLabel = new System.Windows.Forms.Label();
            this.RoleDiscriptionLabel = new System.Windows.Forms.Label();
            this.groupDiscriptionLabel1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Groups_FunctionsButton = new System.Windows.Forms.Button();
            this.taskSaveButton = new System.Windows.Forms.Button();
            this.Details = new System.Windows.Forms.TabPage();
            this.MembershipComboBox = new System.Windows.Forms.ComboBox();
            this.SurnameComboBox = new System.Windows.Forms.ComboBox();
            this.genderComboBox = new System.Windows.Forms.ComboBox();
            this.GenderLable = new System.Windows.Forms.Label();
            this.AdressRichTextBox = new System.Windows.Forms.RichTextBox();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.contactNumberTextBox2 = new System.Windows.Forms.TextBox();
            this.emailtextBox = new System.Windows.Forms.TextBox();
            this.contactNumberTextBox1 = new System.Windows.Forms.TextBox();
            this.MeritalSCheckedListBox = new System.Windows.Forms.CheckedListBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.detailsSaveButton = new System.Windows.Forms.Button();
            this.SendNewsLettersCheckBox = new System.Windows.Forms.CheckBox();
            this.DOBNonApplicableCHKB = new System.Windows.Forms.CheckBox();
            this.DOBDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.MemberShipLabel = new System.Windows.Forms.Label();
            this.SurnameLabel = new System.Windows.Forms.Label();
            this.DOBLabel = new System.Windows.Forms.Label();
            this.meritalStatus = new System.Windows.Forms.Label();
            this.ContactNLabel2 = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.ContactNLabel1 = new System.Windows.Forms.Label();
            this.AdressLabel = new System.Windows.Forms.Label();
            this.familyBTN = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.memberDetailsTableAdapter = new wrs_management.wrsMembersDataSetTableAdapters.memberDetailsTableAdapter();
            this.familiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.familiesTableAdapter = new wrs_management.wrsMembersDataSetTableAdapters.familiesTableAdapter();
            this.groupsFunctionTableAdapter = new wrs_management.wrsMembersDataSetTableAdapters.GroupsFunctionTableAdapter();
            this.memberGroupTableAdapter = new wrs_management.wrsMembersDataSetTableAdapters.memberGroupTableAdapter();
            this.EmploymentStatusLbl = new System.Windows.Forms.Label();
            this.EmploymentStatusComboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memberDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrsMembersDataSet)).BeginInit();
            this.keepIntouch.SuspendLayout();
            this.TaskAssignments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.taskAssignmentDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionBindingSource)).BeginInit();
            this.GroupFunction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memberGroupBindingSource)).BeginInit();
            this.Details.SuspendLayout();
            this.tabControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.familiesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(71, 518);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(75, 23);
            this.BackButton.TabIndex = 0;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(12, 20);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 67);
            this.addButton.TabIndex = 1;
            this.addButton.Text = "Add Member";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(177, 20);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(75, 67);
            this.deleteButton.TabIndex = 3;
            this.deleteButton.Text = "Delete Member";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(95, 20);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(75, 67);
            this.editButton.TabIndex = 2;
            this.editButton.Text = "Edit Member";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.memberDetailsIDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.membershipDataGridViewTextBoxColumn,
            this.meritalStatusDataGridViewTextBoxColumn,
            this.dateOfBirthDataGridViewTextBoxColumn,
            this.adressDataGridViewTextBoxColumn,
            this.contactNumberDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.memberDetailsBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowFrame;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.InactiveCaption;
            this.dataGridView1.Location = new System.Drawing.Point(12, 93);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.LightSlateGray;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(204)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.SteelBlue;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(240, 408);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // memberDetailsIDDataGridViewTextBoxColumn
            // 
            this.memberDetailsIDDataGridViewTextBoxColumn.DataPropertyName = "memberDetailsID";
            this.memberDetailsIDDataGridViewTextBoxColumn.HeaderText = "memberDetailsID";
            this.memberDetailsIDDataGridViewTextBoxColumn.Name = "memberDetailsIDDataGridViewTextBoxColumn";
            this.memberDetailsIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.memberDetailsIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 80;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "surname";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.surnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            this.genderDataGridViewTextBoxColumn.ReadOnly = true;
            this.genderDataGridViewTextBoxColumn.Width = 80;
            // 
            // membershipDataGridViewTextBoxColumn
            // 
            this.membershipDataGridViewTextBoxColumn.DataPropertyName = "membership";
            this.membershipDataGridViewTextBoxColumn.HeaderText = "membership";
            this.membershipDataGridViewTextBoxColumn.Name = "membershipDataGridViewTextBoxColumn";
            this.membershipDataGridViewTextBoxColumn.ReadOnly = true;
            this.membershipDataGridViewTextBoxColumn.Visible = false;
            // 
            // meritalStatusDataGridViewTextBoxColumn
            // 
            this.meritalStatusDataGridViewTextBoxColumn.DataPropertyName = "merital status";
            this.meritalStatusDataGridViewTextBoxColumn.HeaderText = "merital status";
            this.meritalStatusDataGridViewTextBoxColumn.Name = "meritalStatusDataGridViewTextBoxColumn";
            this.meritalStatusDataGridViewTextBoxColumn.ReadOnly = true;
            this.meritalStatusDataGridViewTextBoxColumn.Visible = false;
            // 
            // dateOfBirthDataGridViewTextBoxColumn
            // 
            this.dateOfBirthDataGridViewTextBoxColumn.DataPropertyName = "dateOfBirth";
            this.dateOfBirthDataGridViewTextBoxColumn.HeaderText = "dateOfBirth";
            this.dateOfBirthDataGridViewTextBoxColumn.Name = "dateOfBirthDataGridViewTextBoxColumn";
            this.dateOfBirthDataGridViewTextBoxColumn.ReadOnly = true;
            this.dateOfBirthDataGridViewTextBoxColumn.Visible = false;
            // 
            // adressDataGridViewTextBoxColumn
            // 
            this.adressDataGridViewTextBoxColumn.DataPropertyName = "Adress";
            this.adressDataGridViewTextBoxColumn.HeaderText = "Adress";
            this.adressDataGridViewTextBoxColumn.Name = "adressDataGridViewTextBoxColumn";
            this.adressDataGridViewTextBoxColumn.ReadOnly = true;
            this.adressDataGridViewTextBoxColumn.Visible = false;
            // 
            // contactNumberDataGridViewTextBoxColumn
            // 
            this.contactNumberDataGridViewTextBoxColumn.DataPropertyName = "contactNumber";
            this.contactNumberDataGridViewTextBoxColumn.HeaderText = "contactNumber";
            this.contactNumberDataGridViewTextBoxColumn.Name = "contactNumberDataGridViewTextBoxColumn";
            this.contactNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.contactNumberDataGridViewTextBoxColumn.Visible = false;
            // 
            // memberDetailsBindingSource
            // 
            this.memberDetailsBindingSource.DataMember = "memberDetails";
            this.memberDetailsBindingSource.DataSource = this.wrsMembersDataSet;
            // 
            // wrsMembersDataSet
            // 
            this.wrsMembersDataSet.DataSetName = "wrsMembersDataSet";
            this.wrsMembersDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // keepIntouch
            // 
            this.keepIntouch.Controls.Add(this.MassegeLable);
            this.keepIntouch.Controls.Add(this.richTextBox2);
            this.keepIntouch.Controls.Add(this.richTextBox1);
            this.keepIntouch.Controls.Add(this.sendButton);
            this.keepIntouch.Location = new System.Drawing.Point(4, 22);
            this.keepIntouch.Name = "keepIntouch";
            this.keepIntouch.Size = new System.Drawing.Size(527, 533);
            this.keepIntouch.TabIndex = 3;
            this.keepIntouch.Text = "Communications";
            this.keepIntouch.UseVisualStyleBackColor = true;
            // 
            // MassegeLable
            // 
            this.MassegeLable.AutoSize = true;
            this.MassegeLable.Location = new System.Drawing.Point(6, 302);
            this.MassegeLable.Name = "MassegeLable";
            this.MassegeLable.Size = new System.Drawing.Size(56, 13);
            this.MassegeLable.TabIndex = 36;
            this.MassegeLable.Text = "Massege :";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Enabled = false;
            this.richTextBox2.Location = new System.Drawing.Point(20, 321);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBox2.Size = new System.Drawing.Size(488, 131);
            this.richTextBox2.TabIndex = 1;
            this.richTextBox2.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Location = new System.Drawing.Point(19, 5);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(488, 231);
            this.richTextBox1.TabIndex = 5;
            this.richTextBox1.Text = "";
            // 
            // sendButton
            // 
            this.sendButton.Location = new System.Drawing.Point(20, 458);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(488, 50);
            this.sendButton.TabIndex = 2;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = true;
            this.sendButton.Visible = false;
            // 
            // TaskAssignments
            // 
            this.TaskAssignments.Controls.Add(this.taskAssignmentDataGridView);
            this.TaskAssignments.Controls.Add(this.cancelButton3);
            this.TaskAssignments.Controls.Add(this.taskAssignmentsStatusComboBox);
            this.TaskAssignments.Controls.Add(this.taskAssignmentsDueDateTimePicker);
            this.TaskAssignments.Controls.Add(this.taskAssignmentsStartDateTimePicker);
            this.TaskAssignments.Controls.Add(this.taskAssignmentsRichTextBox);
            this.TaskAssignments.Controls.Add(this.taskAssignmentsNameTextBox);
            this.TaskAssignments.Controls.Add(this.label7);
            this.TaskAssignments.Controls.Add(this.label3);
            this.TaskAssignments.Controls.Add(this.label5);
            this.TaskAssignments.Controls.Add(this.label2);
            this.TaskAssignments.Controls.Add(this.label1);
            this.TaskAssignments.Controls.Add(this.tasksButton);
            this.TaskAssignments.Controls.Add(this.taskAssignmentsSaveButton);
            this.TaskAssignments.Location = new System.Drawing.Point(4, 22);
            this.TaskAssignments.Name = "TaskAssignments";
            this.TaskAssignments.Size = new System.Drawing.Size(527, 533);
            this.TaskAssignments.TabIndex = 2;
            this.TaskAssignments.Text = "Task Assignments";
            this.TaskAssignments.UseVisualStyleBackColor = true;
            // 
            // taskAssignmentDataGridView
            // 
            this.taskAssignmentDataGridView.AutoGenerateColumns = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.taskAssignmentDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.taskAssignmentDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.taskAssignmentDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.groupFunctionIDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn1,
            this.discriptionDataGridViewTextBoxColumn,
            this.missionDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn});
            this.taskAssignmentDataGridView.DataSource = this.groupsFunctionBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.taskAssignmentDataGridView.DefaultCellStyle = dataGridViewCellStyle7;
            this.taskAssignmentDataGridView.Location = new System.Drawing.Point(17, 24);
            this.taskAssignmentDataGridView.Name = "taskAssignmentDataGridView";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.taskAssignmentDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.taskAssignmentDataGridView.Size = new System.Drawing.Size(125, 478);
            this.taskAssignmentDataGridView.TabIndex = 35;
            // 
            // groupFunctionIDDataGridViewTextBoxColumn
            // 
            this.groupFunctionIDDataGridViewTextBoxColumn.DataPropertyName = "groupFunctionID";
            this.groupFunctionIDDataGridViewTextBoxColumn.HeaderText = "groupFunctionID";
            this.groupFunctionIDDataGridViewTextBoxColumn.Name = "groupFunctionIDDataGridViewTextBoxColumn";
            this.groupFunctionIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            // 
            // discriptionDataGridViewTextBoxColumn
            // 
            this.discriptionDataGridViewTextBoxColumn.DataPropertyName = "discription";
            this.discriptionDataGridViewTextBoxColumn.HeaderText = "discription";
            this.discriptionDataGridViewTextBoxColumn.Name = "discriptionDataGridViewTextBoxColumn";
            // 
            // missionDataGridViewTextBoxColumn
            // 
            this.missionDataGridViewTextBoxColumn.DataPropertyName = "mission";
            this.missionDataGridViewTextBoxColumn.HeaderText = "mission";
            this.missionDataGridViewTextBoxColumn.Name = "missionDataGridViewTextBoxColumn";
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "startDate";
            this.startDateDataGridViewTextBoxColumn.HeaderText = "startDate";
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            // 
            // groupsFunctionBindingSource
            // 
            this.groupsFunctionBindingSource.DataMember = "GroupsFunction";
            this.groupsFunctionBindingSource.DataSource = this.wrsMembersDataSet;
            // 
            // cancelButton3
            // 
            this.cancelButton3.Location = new System.Drawing.Point(216, 458);
            this.cancelButton3.Name = "cancelButton3";
            this.cancelButton3.Size = new System.Drawing.Size(75, 23);
            this.cancelButton3.TabIndex = 34;
            this.cancelButton3.Text = "Cancel";
            this.cancelButton3.UseVisualStyleBackColor = true;
            this.cancelButton3.Visible = false;
            // 
            // taskAssignmentsStatusComboBox
            // 
            this.taskAssignmentsStatusComboBox.Enabled = false;
            this.taskAssignmentsStatusComboBox.FormattingEnabled = true;
            this.taskAssignmentsStatusComboBox.Items.AddRange(new object[] {
            "complete",
            "incomplete"});
            this.taskAssignmentsStatusComboBox.Location = new System.Drawing.Point(277, 290);
            this.taskAssignmentsStatusComboBox.Name = "taskAssignmentsStatusComboBox";
            this.taskAssignmentsStatusComboBox.Size = new System.Drawing.Size(121, 21);
            this.taskAssignmentsStatusComboBox.TabIndex = 19;
            // 
            // taskAssignmentsDueDateTimePicker
            // 
            this.taskAssignmentsDueDateTimePicker.Enabled = false;
            this.taskAssignmentsDueDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.taskAssignmentsDueDateTimePicker.Location = new System.Drawing.Point(277, 94);
            this.taskAssignmentsDueDateTimePicker.Name = "taskAssignmentsDueDateTimePicker";
            this.taskAssignmentsDueDateTimePicker.Size = new System.Drawing.Size(120, 20);
            this.taskAssignmentsDueDateTimePicker.TabIndex = 18;
            // 
            // taskAssignmentsStartDateTimePicker
            // 
            this.taskAssignmentsStartDateTimePicker.Enabled = false;
            this.taskAssignmentsStartDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.taskAssignmentsStartDateTimePicker.Location = new System.Drawing.Point(277, 56);
            this.taskAssignmentsStartDateTimePicker.Name = "taskAssignmentsStartDateTimePicker";
            this.taskAssignmentsStartDateTimePicker.Size = new System.Drawing.Size(120, 20);
            this.taskAssignmentsStartDateTimePicker.TabIndex = 18;
            // 
            // taskAssignmentsRichTextBox
            // 
            this.taskAssignmentsRichTextBox.Enabled = false;
            this.taskAssignmentsRichTextBox.Location = new System.Drawing.Point(216, 156);
            this.taskAssignmentsRichTextBox.Name = "taskAssignmentsRichTextBox";
            this.taskAssignmentsRichTextBox.Size = new System.Drawing.Size(256, 105);
            this.taskAssignmentsRichTextBox.TabIndex = 4;
            this.taskAssignmentsRichTextBox.Text = "";
            // 
            // taskAssignmentsNameTextBox
            // 
            this.taskAssignmentsNameTextBox.Enabled = false;
            this.taskAssignmentsNameTextBox.Location = new System.Drawing.Point(277, 24);
            this.taskAssignmentsNameTextBox.Name = "taskAssignmentsNameTextBox";
            this.taskAssignmentsNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.taskAssignmentsNameTextBox.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(213, 298);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(213, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Task Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(213, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Due Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(213, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Discription";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(213, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Start Date";
            // 
            // tasksButton
            // 
            this.tasksButton.Location = new System.Drawing.Point(277, 376);
            this.tasksButton.Name = "tasksButton";
            this.tasksButton.Size = new System.Drawing.Size(147, 23);
            this.tasksButton.TabIndex = 1;
            this.tasksButton.Text = "Tasks";
            this.tasksButton.UseVisualStyleBackColor = true;
            // 
            // taskAssignmentsSaveButton
            // 
            this.taskAssignmentsSaveButton.Location = new System.Drawing.Point(439, 458);
            this.taskAssignmentsSaveButton.Name = "taskAssignmentsSaveButton";
            this.taskAssignmentsSaveButton.Size = new System.Drawing.Size(75, 23);
            this.taskAssignmentsSaveButton.TabIndex = 1;
            this.taskAssignmentsSaveButton.Text = "Save";
            this.taskAssignmentsSaveButton.UseVisualStyleBackColor = true;
            this.taskAssignmentsSaveButton.Visible = false;
            // 
            // GroupFunction
            // 
            this.GroupFunction.Controls.Add(this.groupsFunctionTypecomboBox);
            this.GroupFunction.Controls.Add(this.groupsFunctionTypelabel);
            this.GroupFunction.Controls.Add(this.groupsFunctionsDataGridView);
            this.GroupFunction.Controls.Add(this.dataGridView2);
            this.GroupFunction.Controls.Add(this.GFCancelButton);
            this.GroupFunction.Controls.Add(this.comboBox1);
            this.GroupFunction.Controls.Add(this.groupsFunctionRolesComboBox);
            this.GroupFunction.Controls.Add(this.foundationDateDateTimePicker);
            this.GroupFunction.Controls.Add(this.RoleDiscriptionRichTextBox);
            this.GroupFunction.Controls.Add(this.groupDiscriptionRichTextBox);
            this.GroupFunction.Controls.Add(this.label9);
            this.GroupFunction.Controls.Add(this.foundationDateLabel);
            this.GroupFunction.Controls.Add(this.RoleDiscriptionLabel);
            this.GroupFunction.Controls.Add(this.groupDiscriptionLabel1);
            this.GroupFunction.Controls.Add(this.label12);
            this.GroupFunction.Controls.Add(this.Groups_FunctionsButton);
            this.GroupFunction.Controls.Add(this.taskSaveButton);
            this.GroupFunction.Location = new System.Drawing.Point(4, 22);
            this.GroupFunction.Name = "GroupFunction";
            this.GroupFunction.Padding = new System.Windows.Forms.Padding(3);
            this.GroupFunction.Size = new System.Drawing.Size(527, 533);
            this.GroupFunction.TabIndex = 1;
            this.GroupFunction.Text = "Group/function";
            this.GroupFunction.UseVisualStyleBackColor = true;
            // 
            // groupsFunctionTypecomboBox
            // 
            this.groupsFunctionTypecomboBox.FormattingEnabled = true;
            this.groupsFunctionTypecomboBox.Items.AddRange(new object[] {
            "Group",
            "Task",
            "Functions"});
            this.groupsFunctionTypecomboBox.Location = new System.Drawing.Point(314, 56);
            this.groupsFunctionTypecomboBox.Name = "groupsFunctionTypecomboBox";
            this.groupsFunctionTypecomboBox.Size = new System.Drawing.Size(121, 21);
            this.groupsFunctionTypecomboBox.TabIndex = 60;
            // 
            // groupsFunctionTypelabel
            // 
            this.groupsFunctionTypelabel.AutoSize = true;
            this.groupsFunctionTypelabel.Location = new System.Drawing.Point(216, 64);
            this.groupsFunctionTypelabel.Name = "groupsFunctionTypelabel";
            this.groupsFunctionTypelabel.Size = new System.Drawing.Size(31, 13);
            this.groupsFunctionTypelabel.TabIndex = 59;
            this.groupsFunctionTypelabel.Text = "Type";
            // 
            // groupsFunctionsDataGridView
            // 
            this.groupsFunctionsDataGridView.AllowUserToAddRows = false;
            this.groupsFunctionsDataGridView.AllowUserToDeleteRows = false;
            this.groupsFunctionsDataGridView.AllowUserToResizeColumns = false;
            this.groupsFunctionsDataGridView.AllowUserToResizeRows = false;
            this.groupsFunctionsDataGridView.AutoGenerateColumns = false;
            this.groupsFunctionsDataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.groupsFunctionsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.groupsFunctionsDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.groupsFunctionsDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.groupsFunctionsDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.groupsFunctionsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.groupsFunctionsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.name,
            this.discription,
            this.mission,
            this.startDate});
            this.groupsFunctionsDataGridView.DataSource = this.groupsFunctionBindingSource1;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.groupsFunctionsDataGridView.DefaultCellStyle = dataGridViewCellStyle10;
            this.groupsFunctionsDataGridView.GridColor = System.Drawing.SystemColors.Control;
            this.groupsFunctionsDataGridView.Location = new System.Drawing.Point(6, 8);
            this.groupsFunctionsDataGridView.MultiSelect = false;
            this.groupsFunctionsDataGridView.Name = "groupsFunctionsDataGridView";
            this.groupsFunctionsDataGridView.ReadOnly = true;
            this.groupsFunctionsDataGridView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.groupsFunctionsDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.groupsFunctionsDataGridView.RowHeadersVisible = false;
            this.groupsFunctionsDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.groupsFunctionsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.groupsFunctionsDataGridView.Size = new System.Drawing.Size(200, 471);
            this.groupsFunctionsDataGridView.TabIndex = 37;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "groupFunctionID";
            this.dataGridViewTextBoxColumn3.HeaderText = "groupFunctionID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            this.name.Width = 80;
            // 
            // discription
            // 
            this.discription.DataPropertyName = "discription";
            this.discription.HeaderText = "discription";
            this.discription.Name = "discription";
            this.discription.ReadOnly = true;
            this.discription.Width = 120;
            // 
            // mission
            // 
            this.mission.DataPropertyName = "mission";
            this.mission.HeaderText = "mission";
            this.mission.Name = "mission";
            this.mission.ReadOnly = true;
            this.mission.Visible = false;
            // 
            // startDate
            // 
            this.startDate.DataPropertyName = "startDate";
            this.startDate.HeaderText = "startDate";
            this.startDate.Name = "startDate";
            this.startDate.ReadOnly = true;
            this.startDate.Visible = false;
            // 
            // groupsFunctionBindingSource1
            // 
            this.groupsFunctionBindingSource1.DataMember = "GroupsFunction";
            this.groupsFunctionBindingSource1.DataSource = this.wrsMembersDataSet;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.memberGroupIDDataGridViewTextBoxColumn,
            this.memberDetailsIDDataGridViewTextBoxColumn1,
            this.groupFunctionIDDataGridViewTextBoxColumn1,
            this.memberFunctionDataGridViewTextBoxColumn,
            this.functionDiscriptionDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.memberGroupBindingSource;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView2.Location = new System.Drawing.Point(6, 494);
            this.dataGridView2.Name = "dataGridView2";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.Size = new System.Drawing.Size(512, 34);
            this.dataGridView2.TabIndex = 36;
            this.dataGridView2.Visible = false;
            // 
            // memberGroupIDDataGridViewTextBoxColumn
            // 
            this.memberGroupIDDataGridViewTextBoxColumn.DataPropertyName = "memberGroupID";
            this.memberGroupIDDataGridViewTextBoxColumn.HeaderText = "memberGroupID";
            this.memberGroupIDDataGridViewTextBoxColumn.Name = "memberGroupIDDataGridViewTextBoxColumn";
            this.memberGroupIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // memberDetailsIDDataGridViewTextBoxColumn1
            // 
            this.memberDetailsIDDataGridViewTextBoxColumn1.DataPropertyName = "memberDetailsID";
            this.memberDetailsIDDataGridViewTextBoxColumn1.HeaderText = "memberDetailsID";
            this.memberDetailsIDDataGridViewTextBoxColumn1.Name = "memberDetailsIDDataGridViewTextBoxColumn1";
            // 
            // groupFunctionIDDataGridViewTextBoxColumn1
            // 
            this.groupFunctionIDDataGridViewTextBoxColumn1.DataPropertyName = "groupFunctionID";
            this.groupFunctionIDDataGridViewTextBoxColumn1.HeaderText = "groupFunctionID";
            this.groupFunctionIDDataGridViewTextBoxColumn1.Name = "groupFunctionIDDataGridViewTextBoxColumn1";
            // 
            // memberFunctionDataGridViewTextBoxColumn
            // 
            this.memberFunctionDataGridViewTextBoxColumn.DataPropertyName = "memberFunction";
            this.memberFunctionDataGridViewTextBoxColumn.HeaderText = "memberFunction";
            this.memberFunctionDataGridViewTextBoxColumn.Name = "memberFunctionDataGridViewTextBoxColumn";
            // 
            // functionDiscriptionDataGridViewTextBoxColumn
            // 
            this.functionDiscriptionDataGridViewTextBoxColumn.DataPropertyName = "functionDiscription";
            this.functionDiscriptionDataGridViewTextBoxColumn.HeaderText = "functionDiscription";
            this.functionDiscriptionDataGridViewTextBoxColumn.Name = "functionDiscriptionDataGridViewTextBoxColumn";
            // 
            // memberGroupBindingSource
            // 
            this.memberGroupBindingSource.DataMember = "memberGroup";
            this.memberGroupBindingSource.DataSource = this.wrsMembersDataSet;
            // 
            // GFCancelButton
            // 
            this.GFCancelButton.Location = new System.Drawing.Point(216, 465);
            this.GFCancelButton.Name = "GFCancelButton";
            this.GFCancelButton.Size = new System.Drawing.Size(75, 23);
            this.GFCancelButton.TabIndex = 33;
            this.GFCancelButton.Text = "Cancel";
            this.GFCancelButton.UseVisualStyleBackColor = true;
            this.GFCancelButton.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Chairperson",
            "Secritary",
            "Member",
            "Leader"});
            this.comboBox1.Location = new System.Drawing.Point(314, 20);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 32;
            // 
            // groupsFunctionRolesComboBox
            // 
            this.groupsFunctionRolesComboBox.Enabled = false;
            this.groupsFunctionRolesComboBox.FormattingEnabled = true;
            this.groupsFunctionRolesComboBox.Items.AddRange(new object[] {
            "Chairperson",
            "Secritary",
            "Member",
            "Leader"});
            this.groupsFunctionRolesComboBox.Location = new System.Drawing.Point(315, 92);
            this.groupsFunctionRolesComboBox.Name = "groupsFunctionRolesComboBox";
            this.groupsFunctionRolesComboBox.Size = new System.Drawing.Size(121, 21);
            this.groupsFunctionRolesComboBox.TabIndex = 30;
            // 
            // foundationDateDateTimePicker
            // 
            this.foundationDateDateTimePicker.Enabled = false;
            this.foundationDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.foundationDateDateTimePicker.Location = new System.Drawing.Point(326, 261);
            this.foundationDateDateTimePicker.Name = "foundationDateDateTimePicker";
            this.foundationDateDateTimePicker.Size = new System.Drawing.Size(120, 20);
            this.foundationDateDateTimePicker.TabIndex = 28;
            // 
            // RoleDiscriptionRichTextBox
            // 
            this.RoleDiscriptionRichTextBox.Enabled = false;
            this.RoleDiscriptionRichTextBox.Location = new System.Drawing.Point(216, 144);
            this.RoleDiscriptionRichTextBox.Name = "RoleDiscriptionRichTextBox";
            this.RoleDiscriptionRichTextBox.Size = new System.Drawing.Size(256, 105);
            this.RoleDiscriptionRichTextBox.TabIndex = 27;
            this.RoleDiscriptionRichTextBox.Text = "";
            // 
            // groupDiscriptionRichTextBox
            // 
            this.groupDiscriptionRichTextBox.Enabled = false;
            this.groupDiscriptionRichTextBox.Location = new System.Drawing.Point(216, 313);
            this.groupDiscriptionRichTextBox.Name = "groupDiscriptionRichTextBox";
            this.groupDiscriptionRichTextBox.Size = new System.Drawing.Size(256, 105);
            this.groupDiscriptionRichTextBox.TabIndex = 27;
            this.groupDiscriptionRichTextBox.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(216, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "group/function";
            // 
            // foundationDateLabel
            // 
            this.foundationDateLabel.AutoSize = true;
            this.foundationDateLabel.Location = new System.Drawing.Point(216, 268);
            this.foundationDateLabel.Name = "foundationDateLabel";
            this.foundationDateLabel.Size = new System.Drawing.Size(83, 13);
            this.foundationDateLabel.TabIndex = 23;
            this.foundationDateLabel.Text = "foundation Date";
            // 
            // RoleDiscriptionLabel
            // 
            this.RoleDiscriptionLabel.AutoSize = true;
            this.RoleDiscriptionLabel.Location = new System.Drawing.Point(216, 126);
            this.RoleDiscriptionLabel.Name = "RoleDiscriptionLabel";
            this.RoleDiscriptionLabel.Size = new System.Drawing.Size(81, 13);
            this.RoleDiscriptionLabel.TabIndex = 24;
            this.RoleDiscriptionLabel.Text = "Role Discription";
            // 
            // groupDiscriptionLabel1
            // 
            this.groupDiscriptionLabel1.AutoSize = true;
            this.groupDiscriptionLabel1.Location = new System.Drawing.Point(216, 297);
            this.groupDiscriptionLabel1.Name = "groupDiscriptionLabel1";
            this.groupDiscriptionLabel1.Size = new System.Drawing.Size(88, 13);
            this.groupDiscriptionLabel1.TabIndex = 24;
            this.groupDiscriptionLabel1.Text = "Group Discription";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(216, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "Role";
            // 
            // Groups_FunctionsButton
            // 
            this.Groups_FunctionsButton.Location = new System.Drawing.Point(293, 429);
            this.Groups_FunctionsButton.Name = "Groups_FunctionsButton";
            this.Groups_FunctionsButton.Size = new System.Drawing.Size(147, 23);
            this.Groups_FunctionsButton.TabIndex = 1;
            this.Groups_FunctionsButton.Text = "Groups and Functions";
            this.Groups_FunctionsButton.UseVisualStyleBackColor = true;
            this.Groups_FunctionsButton.Click += new System.EventHandler(this.Groups_FunctionsButton_Click);
            // 
            // taskSaveButton
            // 
            this.taskSaveButton.Location = new System.Drawing.Point(442, 465);
            this.taskSaveButton.Name = "taskSaveButton";
            this.taskSaveButton.Size = new System.Drawing.Size(75, 23);
            this.taskSaveButton.TabIndex = 1;
            this.taskSaveButton.Text = "Save";
            this.taskSaveButton.UseVisualStyleBackColor = true;
            this.taskSaveButton.Visible = false;
            // 
            // Details
            // 
            this.Details.Controls.Add(this.EmploymentStatusComboBox);
            this.Details.Controls.Add(this.MembershipComboBox);
            this.Details.Controls.Add(this.SurnameComboBox);
            this.Details.Controls.Add(this.genderComboBox);
            this.Details.Controls.Add(this.GenderLable);
            this.Details.Controls.Add(this.AdressRichTextBox);
            this.Details.Controls.Add(this.NameTextBox);
            this.Details.Controls.Add(this.contactNumberTextBox2);
            this.Details.Controls.Add(this.emailtextBox);
            this.Details.Controls.Add(this.contactNumberTextBox1);
            this.Details.Controls.Add(this.MeritalSCheckedListBox);
            this.Details.Controls.Add(this.cancelButton);
            this.Details.Controls.Add(this.detailsSaveButton);
            this.Details.Controls.Add(this.SendNewsLettersCheckBox);
            this.Details.Controls.Add(this.DOBNonApplicableCHKB);
            this.Details.Controls.Add(this.DOBDateTimePicker);
            this.Details.Controls.Add(this.EmploymentStatusLbl);
            this.Details.Controls.Add(this.MemberShipLabel);
            this.Details.Controls.Add(this.SurnameLabel);
            this.Details.Controls.Add(this.DOBLabel);
            this.Details.Controls.Add(this.meritalStatus);
            this.Details.Controls.Add(this.ContactNLabel2);
            this.Details.Controls.Add(this.NameLabel);
            this.Details.Controls.Add(this.emailLabel);
            this.Details.Controls.Add(this.ContactNLabel1);
            this.Details.Controls.Add(this.AdressLabel);
            this.Details.Controls.Add(this.familyBTN);
            this.Details.Location = new System.Drawing.Point(4, 22);
            this.Details.Name = "Details";
            this.Details.Padding = new System.Windows.Forms.Padding(3);
            this.Details.Size = new System.Drawing.Size(527, 533);
            this.Details.TabIndex = 0;
            this.Details.Text = "Details";
            this.Details.UseVisualStyleBackColor = true;
            // 
            // MembershipComboBox
            // 
            this.MembershipComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Member",
            "Visitor",
            "Non Member"});
            this.MembershipComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.MembershipComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.MembershipComboBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MembershipComboBox.Enabled = false;
            this.MembershipComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MembershipComboBox.FormattingEnabled = true;
            this.MembershipComboBox.Items.AddRange(new object[] {
            "Member",
            "Visitor",
            "Non Member"});
            this.MembershipComboBox.Location = new System.Drawing.Point(136, 144);
            this.MembershipComboBox.Name = "MembershipComboBox";
            this.MembershipComboBox.Size = new System.Drawing.Size(121, 21);
            this.MembershipComboBox.TabIndex = 5;
            // 
            // SurnameComboBox
            // 
            this.SurnameComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Male",
            "Female"});
            this.SurnameComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.SurnameComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.SurnameComboBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SurnameComboBox.Enabled = false;
            this.SurnameComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SurnameComboBox.FormattingEnabled = true;
            this.SurnameComboBox.Location = new System.Drawing.Point(136, 63);
            this.SurnameComboBox.Name = "SurnameComboBox";
            this.SurnameComboBox.Size = new System.Drawing.Size(121, 21);
            this.SurnameComboBox.TabIndex = 2;
            // 
            // genderComboBox
            // 
            this.genderComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Male",
            "Female"});
            this.genderComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.genderComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.genderComboBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.genderComboBox.Enabled = false;
            this.genderComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.genderComboBox.FormattingEnabled = true;
            this.genderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.genderComboBox.Location = new System.Drawing.Point(136, 104);
            this.genderComboBox.Name = "genderComboBox";
            this.genderComboBox.Size = new System.Drawing.Size(121, 21);
            this.genderComboBox.TabIndex = 4;
            // 
            // GenderLable
            // 
            this.GenderLable.AutoSize = true;
            this.GenderLable.Location = new System.Drawing.Point(29, 112);
            this.GenderLable.Name = "GenderLable";
            this.GenderLable.Size = new System.Drawing.Size(42, 13);
            this.GenderLable.TabIndex = 22;
            this.GenderLable.Text = "Gender";
            // 
            // AdressRichTextBox
            // 
            this.AdressRichTextBox.Enabled = false;
            this.AdressRichTextBox.Location = new System.Drawing.Point(136, 279);
            this.AdressRichTextBox.Name = "AdressRichTextBox";
            this.AdressRichTextBox.Size = new System.Drawing.Size(253, 96);
            this.AdressRichTextBox.TabIndex = 9;
            this.AdressRichTextBox.Text = "";
            // 
            // NameTextBox
            // 
            this.NameTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.NameTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.NameTextBox.Enabled = false;
            this.NameTextBox.Location = new System.Drawing.Point(136, 24);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(121, 20);
            this.NameTextBox.TabIndex = 1;
            // 
            // contactNumberTextBox2
            // 
            this.contactNumberTextBox2.Enabled = false;
            this.contactNumberTextBox2.Location = new System.Drawing.Point(136, 421);
            this.contactNumberTextBox2.Name = "contactNumberTextBox2";
            this.contactNumberTextBox2.Size = new System.Drawing.Size(121, 20);
            this.contactNumberTextBox2.TabIndex = 11;
            // 
            // emailtextBox
            // 
            this.emailtextBox.Enabled = false;
            this.emailtextBox.Location = new System.Drawing.Point(136, 449);
            this.emailtextBox.Name = "emailtextBox";
            this.emailtextBox.Size = new System.Drawing.Size(121, 20);
            this.emailtextBox.TabIndex = 12;
            // 
            // contactNumberTextBox1
            // 
            this.contactNumberTextBox1.Enabled = false;
            this.contactNumberTextBox1.Location = new System.Drawing.Point(136, 393);
            this.contactNumberTextBox1.Name = "contactNumberTextBox1";
            this.contactNumberTextBox1.Size = new System.Drawing.Size(121, 20);
            this.contactNumberTextBox1.TabIndex = 10;
            // 
            // MeritalSCheckedListBox
            // 
            this.MeritalSCheckedListBox.Enabled = false;
            this.MeritalSCheckedListBox.FormattingEnabled = true;
            this.MeritalSCheckedListBox.Items.AddRange(new object[] {
            "married",
            "single"});
            this.MeritalSCheckedListBox.Location = new System.Drawing.Point(136, 185);
            this.MeritalSCheckedListBox.Name = "MeritalSCheckedListBox";
            this.MeritalSCheckedListBox.Size = new System.Drawing.Size(121, 34);
            this.MeritalSCheckedListBox.TabIndex = 6;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(32, 507);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 15;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Visible = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // detailsSaveButton
            // 
            this.detailsSaveButton.Location = new System.Drawing.Point(373, 503);
            this.detailsSaveButton.Name = "detailsSaveButton";
            this.detailsSaveButton.Size = new System.Drawing.Size(75, 23);
            this.detailsSaveButton.TabIndex = 14;
            this.detailsSaveButton.Text = "Save";
            this.detailsSaveButton.UseVisualStyleBackColor = true;
            this.detailsSaveButton.Visible = false;
            this.detailsSaveButton.Click += new System.EventHandler(this.detailsSaveButton_Click);
            // 
            // SendNewsLettersCheckBox
            // 
            this.SendNewsLettersCheckBox.AutoSize = true;
            this.SendNewsLettersCheckBox.Enabled = false;
            this.SendNewsLettersCheckBox.Location = new System.Drawing.Point(307, 456);
            this.SendNewsLettersCheckBox.Name = "SendNewsLettersCheckBox";
            this.SendNewsLettersCheckBox.Size = new System.Drawing.Size(116, 17);
            this.SendNewsLettersCheckBox.TabIndex = 13;
            this.SendNewsLettersCheckBox.Text = "Send News Letters";
            this.SendNewsLettersCheckBox.UseVisualStyleBackColor = true;
            // 
            // DOBNonApplicableCHKB
            // 
            this.DOBNonApplicableCHKB.AutoSize = true;
            this.DOBNonApplicableCHKB.Enabled = false;
            this.DOBNonApplicableCHKB.Location = new System.Drawing.Point(340, 242);
            this.DOBNonApplicableCHKB.Name = "DOBNonApplicableCHKB";
            this.DOBNonApplicableCHKB.Size = new System.Drawing.Size(46, 17);
            this.DOBNonApplicableCHKB.TabIndex = 8;
            this.DOBNonApplicableCHKB.Text = "N/A";
            this.DOBNonApplicableCHKB.UseVisualStyleBackColor = true;
            // 
            // DOBDateTimePicker
            // 
            this.DOBDateTimePicker.CustomFormat = "dd/MM/yyyy";
            this.DOBDateTimePicker.Enabled = false;
            this.DOBDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DOBDateTimePicker.Location = new System.Drawing.Point(136, 239);
            this.DOBDateTimePicker.MaxDate = new System.DateTime(2116, 1, 1, 0, 0, 0, 0);
            this.DOBDateTimePicker.MinDate = new System.DateTime(1930, 1, 1, 0, 0, 0, 0);
            this.DOBDateTimePicker.Name = "DOBDateTimePicker";
            this.DOBDateTimePicker.Size = new System.Drawing.Size(121, 20);
            this.DOBDateTimePicker.TabIndex = 7;
            this.DOBDateTimePicker.Value = new System.DateTime(2016, 4, 11, 0, 0, 0, 0);
            // 
            // MemberShipLabel
            // 
            this.MemberShipLabel.AutoSize = true;
            this.MemberShipLabel.Location = new System.Drawing.Point(29, 152);
            this.MemberShipLabel.Name = "MemberShipLabel";
            this.MemberShipLabel.Size = new System.Drawing.Size(64, 13);
            this.MemberShipLabel.TabIndex = 11;
            this.MemberShipLabel.Text = "Membership";
            // 
            // SurnameLabel
            // 
            this.SurnameLabel.AutoSize = true;
            this.SurnameLabel.Location = new System.Drawing.Point(29, 71);
            this.SurnameLabel.Name = "SurnameLabel";
            this.SurnameLabel.Size = new System.Drawing.Size(49, 13);
            this.SurnameLabel.TabIndex = 11;
            this.SurnameLabel.Text = "Surname";
            // 
            // DOBLabel
            // 
            this.DOBLabel.AutoSize = true;
            this.DOBLabel.Location = new System.Drawing.Point(29, 246);
            this.DOBLabel.Name = "DOBLabel";
            this.DOBLabel.Size = new System.Drawing.Size(66, 13);
            this.DOBLabel.TabIndex = 12;
            this.DOBLabel.Text = "Date of Birth";
            // 
            // meritalStatus
            // 
            this.meritalStatus.AutoSize = true;
            this.meritalStatus.Location = new System.Drawing.Point(29, 206);
            this.meritalStatus.Name = "meritalStatus";
            this.meritalStatus.Size = new System.Drawing.Size(71, 13);
            this.meritalStatus.TabIndex = 13;
            this.meritalStatus.Text = "Merital Status";
            // 
            // ContactNLabel2
            // 
            this.ContactNLabel2.AutoSize = true;
            this.ContactNLabel2.Location = new System.Drawing.Point(29, 428);
            this.ContactNLabel2.Name = "ContactNLabel2";
            this.ContactNLabel2.Size = new System.Drawing.Size(99, 13);
            this.ContactNLabel2.TabIndex = 15;
            this.ContactNLabel2.Text = "Alt Contact Number";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(29, 31);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(35, 13);
            this.NameLabel.TabIndex = 14;
            this.NameLabel.Text = "Name";
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(29, 456);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(73, 13);
            this.emailLabel.TabIndex = 15;
            this.emailLabel.Text = "Email Address";
            // 
            // ContactNLabel1
            // 
            this.ContactNLabel1.AutoSize = true;
            this.ContactNLabel1.Location = new System.Drawing.Point(29, 400);
            this.ContactNLabel1.Name = "ContactNLabel1";
            this.ContactNLabel1.Size = new System.Drawing.Size(84, 13);
            this.ContactNLabel1.TabIndex = 15;
            this.ContactNLabel1.Text = "Contact Number";
            // 
            // AdressLabel
            // 
            this.AdressLabel.AutoSize = true;
            this.AdressLabel.Location = new System.Drawing.Point(29, 291);
            this.AdressLabel.Name = "AdressLabel";
            this.AdressLabel.Size = new System.Drawing.Size(45, 13);
            this.AdressLabel.TabIndex = 16;
            this.AdressLabel.Text = "Address";
            // 
            // familyBTN
            // 
            this.familyBTN.Location = new System.Drawing.Point(340, 66);
            this.familyBTN.Name = "familyBTN";
            this.familyBTN.Size = new System.Drawing.Size(75, 23);
            this.familyBTN.TabIndex = 3;
            this.familyBTN.Text = "Families";
            this.familyBTN.UseVisualStyleBackColor = true;
            this.familyBTN.Visible = false;
            this.familyBTN.Click += new System.EventHandler(this.familyBTN_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Details);
            this.tabControl1.Controls.Add(this.GroupFunction);
            this.tabControl1.Controls.Add(this.TaskAssignments);
            this.tabControl1.Controls.Add(this.keepIntouch);
            this.tabControl1.Location = new System.Drawing.Point(258, -2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(535, 559);
            this.tabControl1.TabIndex = 4;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // memberDetailsTableAdapter
            // 
            this.memberDetailsTableAdapter.ClearBeforeFill = true;
            // 
            // familiesBindingSource
            // 
            this.familiesBindingSource.DataMember = "families";
            this.familiesBindingSource.DataSource = this.wrsMembersDataSet;
            // 
            // familiesTableAdapter
            // 
            this.familiesTableAdapter.ClearBeforeFill = true;
            // 
            // groupsFunctionTableAdapter
            // 
            this.groupsFunctionTableAdapter.ClearBeforeFill = true;
            // 
            // memberGroupTableAdapter
            // 
            this.memberGroupTableAdapter.ClearBeforeFill = true;
            // 
            // EmploymentStatusLbl
            // 
            this.EmploymentStatusLbl.AutoSize = true;
            this.EmploymentStatusLbl.Location = new System.Drawing.Point(287, 152);
            this.EmploymentStatusLbl.Name = "EmploymentStatusLbl";
            this.EmploymentStatusLbl.Size = new System.Drawing.Size(97, 13);
            this.EmploymentStatusLbl.TabIndex = 11;
            this.EmploymentStatusLbl.Text = "Employment Status";
            // 
            // EmploymentStatusComboBox
            // 
            this.EmploymentStatusComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Member",
            "Visitor",
            "Non Member"});
            this.EmploymentStatusComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.EmploymentStatusComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.EmploymentStatusComboBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EmploymentStatusComboBox.Enabled = false;
            this.EmploymentStatusComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EmploymentStatusComboBox.FormattingEnabled = true;
            this.EmploymentStatusComboBox.Items.AddRange(new object[] {
            "Employed",
            "Non Employed",
            "Student",
            "Minor"});
            this.EmploymentStatusComboBox.Location = new System.Drawing.Point(394, 144);
            this.EmploymentStatusComboBox.Name = "EmploymentStatusComboBox";
            this.EmploymentStatusComboBox.Size = new System.Drawing.Size(121, 21);
            this.EmploymentStatusComboBox.TabIndex = 5;
            // 
            // members
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 569);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.BackButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "members";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "members";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.members_FormClosed);
            this.Load += new System.EventHandler(this.members_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memberDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrsMembersDataSet)).EndInit();
            this.keepIntouch.ResumeLayout(false);
            this.keepIntouch.PerformLayout();
            this.TaskAssignments.ResumeLayout(false);
            this.TaskAssignments.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.taskAssignmentDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionBindingSource)).EndInit();
            this.GroupFunction.ResumeLayout(false);
            this.GroupFunction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memberGroupBindingSource)).EndInit();
            this.Details.ResumeLayout(false);
            this.Details.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.familiesBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage keepIntouch;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button sendButton;
        private System.Windows.Forms.TabPage TaskAssignments;
        private System.Windows.Forms.ComboBox taskAssignmentsStatusComboBox;
        private System.Windows.Forms.DateTimePicker taskAssignmentsDueDateTimePicker;
        private System.Windows.Forms.DateTimePicker taskAssignmentsStartDateTimePicker;
        private System.Windows.Forms.RichTextBox taskAssignmentsRichTextBox;
        private System.Windows.Forms.TextBox taskAssignmentsNameTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button tasksButton;
        private System.Windows.Forms.Button taskAssignmentsSaveButton;
        private System.Windows.Forms.TabPage GroupFunction;
        private System.Windows.Forms.ComboBox groupsFunctionRolesComboBox;
        private System.Windows.Forms.DateTimePicker foundationDateDateTimePicker;
        private System.Windows.Forms.RichTextBox RoleDiscriptionRichTextBox;
        private System.Windows.Forms.RichTextBox groupDiscriptionRichTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label foundationDateLabel;
        private System.Windows.Forms.Label RoleDiscriptionLabel;
        private System.Windows.Forms.Label groupDiscriptionLabel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Groups_FunctionsButton;
        private System.Windows.Forms.Button taskSaveButton;
        private System.Windows.Forms.TabPage Details;
        private System.Windows.Forms.ComboBox MembershipComboBox;
        private System.Windows.Forms.ComboBox genderComboBox;
        private System.Windows.Forms.Label GenderLable;
        private System.Windows.Forms.RichTextBox AdressRichTextBox;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.TextBox contactNumberTextBox1;
        private System.Windows.Forms.CheckedListBox MeritalSCheckedListBox;
        private System.Windows.Forms.Button detailsSaveButton;
        private System.Windows.Forms.CheckBox DOBNonApplicableCHKB;
        private System.Windows.Forms.DateTimePicker DOBDateTimePicker;
        private System.Windows.Forms.Label MemberShipLabel;
        private System.Windows.Forms.Label SurnameLabel;
        private System.Windows.Forms.Label DOBLabel;
        private System.Windows.Forms.Label meritalStatus;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label ContactNLabel1;
        private System.Windows.Forms.Label AdressLabel;
        private System.Windows.Forms.Button familyBTN;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox SurnameComboBox;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.TextBox contactNumberTextBox2;
        private System.Windows.Forms.TextBox emailtextBox;
        private System.Windows.Forms.CheckBox SendNewsLettersCheckBox;
        private System.Windows.Forms.Label ContactNLabel2;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Button cancelButton3;
        private System.Windows.Forms.Button GFCancelButton;
        private wrsMembersDataSet wrsMembersDataSet;
        private System.Windows.Forms.BindingSource memberDetailsBindingSource;
        private wrsMembersDataSetTableAdapters.memberDetailsTableAdapter memberDetailsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberDetailsIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn membershipDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn meritalStatusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateOfBirthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource familiesBindingSource;
        private wrsMembersDataSetTableAdapters.familiesTableAdapter familiesTableAdapter;
        private System.Windows.Forms.BindingSource groupsFunctionBindingSource;
        private wrsMembersDataSetTableAdapters.GroupsFunctionTableAdapter groupsFunctionTableAdapter;
        private System.Windows.Forms.BindingSource memberGroupBindingSource;
        private wrsMembersDataSetTableAdapters.memberGroupTableAdapter memberGroupTableAdapter;
        private System.Windows.Forms.BindingSource groupsFunctionBindingSource1;
        private System.Windows.Forms.DataGridView taskAssignmentDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn groupFunctionIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn discriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn missionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView groupsFunctionsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn discription;
        private System.Windows.Forms.DataGridViewTextBoxColumn mission;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDate;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberGroupIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberDetailsIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn groupFunctionIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberFunctionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn functionDiscriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label MassegeLable;
        private System.Windows.Forms.ComboBox groupsFunctionTypecomboBox;
        private System.Windows.Forms.Label groupsFunctionTypelabel;
        private System.Windows.Forms.ComboBox EmploymentStatusComboBox;
        private System.Windows.Forms.Label EmploymentStatusLbl;
    }
}