﻿namespace wrs_management
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            this.membersBTN = new System.Windows.Forms.Button();
            this.groupsnFunctionsBTN = new System.Windows.Forms.Button();
            this.FinacesBTN = new System.Windows.Forms.Button();
            this.PEbutton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.DOBDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SurnameLabel = new System.Windows.Forms.Label();
            this.DOBLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.SurnameTextBox = new System.Windows.Forms.TextBox();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.AdminBotton = new System.Windows.Forms.Button();
            this.incomeButton = new System.Windows.Forms.Button();
            this.PersonnelButton = new System.Windows.Forms.Button();
            this.ODMbutton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.EditButton = new System.Windows.Forms.Button();
            this.dashFamiliesButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // membersBTN
            // 
            this.membersBTN.Location = new System.Drawing.Point(12, 12);
            this.membersBTN.Name = "membersBTN";
            this.membersBTN.Size = new System.Drawing.Size(136, 28);
            this.membersBTN.TabIndex = 0;
            this.membersBTN.Text = "Members";
            this.membersBTN.UseVisualStyleBackColor = true;
            this.membersBTN.Click += new System.EventHandler(this.membersBTN_Click);
            // 
            // groupsnFunctionsBTN
            // 
            this.groupsnFunctionsBTN.Location = new System.Drawing.Point(328, 12);
            this.groupsnFunctionsBTN.Name = "groupsnFunctionsBTN";
            this.groupsnFunctionsBTN.Size = new System.Drawing.Size(136, 28);
            this.groupsnFunctionsBTN.TabIndex = 0;
            this.groupsnFunctionsBTN.Text = "Groups and Functions";
            this.groupsnFunctionsBTN.UseVisualStyleBackColor = true;
            this.groupsnFunctionsBTN.Click += new System.EventHandler(this.groupsnFunctionsBTN_Click);
            // 
            // FinacesBTN
            // 
            this.FinacesBTN.Location = new System.Drawing.Point(486, 12);
            this.FinacesBTN.Name = "FinacesBTN";
            this.FinacesBTN.Size = new System.Drawing.Size(136, 28);
            this.FinacesBTN.TabIndex = 0;
            this.FinacesBTN.Text = "Finaces";
            this.FinacesBTN.UseVisualStyleBackColor = true;
            // 
            // PEbutton
            // 
            this.PEbutton.Location = new System.Drawing.Point(528, 253);
            this.PEbutton.Name = "PEbutton";
            this.PEbutton.Size = new System.Drawing.Size(149, 23);
            this.PEbutton.TabIndex = 0;
            this.PEbutton.Text = "Property and equipment";
            this.PEbutton.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 104);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(105, 366);
            this.dataGridView1.TabIndex = 8;
            // 
            // DOBDateTimePicker
            // 
            this.DOBDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DOBDateTimePicker.Location = new System.Drawing.Point(362, 104);
            this.DOBDateTimePicker.Name = "DOBDateTimePicker";
            this.DOBDateTimePicker.Size = new System.Drawing.Size(120, 20);
            this.DOBDateTimePicker.TabIndex = 15;
            // 
            // SurnameLabel
            // 
            this.SurnameLabel.AutoSize = true;
            this.SurnameLabel.Location = new System.Drawing.Point(287, 111);
            this.SurnameLabel.Name = "SurnameLabel";
            this.SurnameLabel.Size = new System.Drawing.Size(51, 13);
            this.SurnameLabel.TabIndex = 11;
            this.SurnameLabel.Text = "Log Date";
            // 
            // DOBLabel
            // 
            this.DOBLabel.AutoSize = true;
            this.DOBLabel.Location = new System.Drawing.Point(270, 149);
            this.DOBLabel.Name = "DOBLabel";
            this.DOBLabel.Size = new System.Drawing.Size(68, 13);
            this.DOBLabel.TabIndex = 12;
            this.DOBLabel.Text = "Total income";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(284, 187);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(54, 13);
            this.NameLabel.TabIndex = 14;
            this.NameLabel.Text = "Personnel";
            // 
            // SurnameTextBox
            // 
            this.SurnameTextBox.Location = new System.Drawing.Point(362, 218);
            this.SurnameTextBox.Name = "SurnameTextBox";
            this.SurnameTextBox.Size = new System.Drawing.Size(120, 20);
            this.SurnameTextBox.TabIndex = 9;
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(362, 142);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(120, 20);
            this.NameTextBox.TabIndex = 10;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(362, 180);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(266, 225);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Administration";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(362, 256);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 20);
            this.textBox2.TabIndex = 10;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(362, 332);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(120, 20);
            this.textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(362, 294);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(120, 20);
            this.textBox4.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(218, 263);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Property and Equipment";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(286, 339);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Bankable";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(199, 301);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Outreach and direct Ministry";
            // 
            // AdminBotton
            // 
            this.AdminBotton.Location = new System.Drawing.Point(528, 215);
            this.AdminBotton.Name = "AdminBotton";
            this.AdminBotton.Size = new System.Drawing.Size(149, 23);
            this.AdminBotton.TabIndex = 0;
            this.AdminBotton.Text = "Administration";
            this.AdminBotton.UseVisualStyleBackColor = true;
            // 
            // incomeButton
            // 
            this.incomeButton.Location = new System.Drawing.Point(528, 139);
            this.incomeButton.Name = "incomeButton";
            this.incomeButton.Size = new System.Drawing.Size(149, 23);
            this.incomeButton.TabIndex = 0;
            this.incomeButton.Text = "Income";
            this.incomeButton.UseVisualStyleBackColor = true;
            this.incomeButton.Click += new System.EventHandler(this.incomeButton_Click);
            // 
            // PersonnelButton
            // 
            this.PersonnelButton.Location = new System.Drawing.Point(528, 177);
            this.PersonnelButton.Name = "PersonnelButton";
            this.PersonnelButton.Size = new System.Drawing.Size(149, 23);
            this.PersonnelButton.TabIndex = 0;
            this.PersonnelButton.Text = "Personnel";
            this.PersonnelButton.UseVisualStyleBackColor = true;
            // 
            // ODMbutton
            // 
            this.ODMbutton.Location = new System.Drawing.Point(528, 291);
            this.ODMbutton.Name = "ODMbutton";
            this.ODMbutton.Size = new System.Drawing.Size(149, 23);
            this.ODMbutton.TabIndex = 0;
            this.ODMbutton.Text = "ODM";
            this.ODMbutton.UseVisualStyleBackColor = true;
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(200, 447);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(75, 23);
            this.deleteButton.TabIndex = 0;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(91, 522);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(407, 447);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 0;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            // 
            // EditButton
            // 
            this.EditButton.Location = new System.Drawing.Point(614, 447);
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(75, 23);
            this.EditButton.TabIndex = 0;
            this.EditButton.Text = "Edit";
            this.EditButton.UseVisualStyleBackColor = true;
            // 
            // dashFamiliesButton
            // 
            this.dashFamiliesButton.Location = new System.Drawing.Point(170, 12);
            this.dashFamiliesButton.Name = "dashFamiliesButton";
            this.dashFamiliesButton.Size = new System.Drawing.Size(136, 28);
            this.dashFamiliesButton.TabIndex = 0;
            this.dashFamiliesButton.Text = "Families";
            this.dashFamiliesButton.UseVisualStyleBackColor = true;
            this.dashFamiliesButton.Click += new System.EventHandler(this.dashFamiliesButton_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(644, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 28);
            this.button1.TabIndex = 0;
            this.button1.Text = "Communication";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 569);
            this.Controls.Add(this.DOBDateTimePicker);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.SurnameLabel);
            this.Controls.Add(this.DOBLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.SurnameTextBox);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.NameTextBox);
            this.Controls.Add(this.PersonnelButton);
            this.Controls.Add(this.incomeButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.AdminBotton);
            this.Controls.Add(this.EditButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.ODMbutton);
            this.Controls.Add(this.PEbutton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.FinacesBTN);
            this.Controls.Add(this.groupsnFunctionsBTN);
            this.Controls.Add(this.dashFamiliesButton);
            this.Controls.Add(this.membersBTN);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dashboard";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button membersBTN;
        private System.Windows.Forms.Button groupsnFunctionsBTN;
        private System.Windows.Forms.Button FinacesBTN;
        private System.Windows.Forms.Button PEbutton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker DOBDateTimePicker;
        private System.Windows.Forms.Label SurnameLabel;
        private System.Windows.Forms.Label DOBLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.TextBox SurnameTextBox;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button AdminBotton;
        private System.Windows.Forms.Button incomeButton;
        private System.Windows.Forms.Button PersonnelButton;
        private System.Windows.Forms.Button ODMbutton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button EditButton;
        private System.Windows.Forms.Button dashFamiliesButton;
        private System.Windows.Forms.Button button1;
    }
}

