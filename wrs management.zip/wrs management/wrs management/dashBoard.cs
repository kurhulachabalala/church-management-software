﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wrs_management
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }

        
        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void incomeButton_Click(object sender, EventArgs e)
        {
            new churchIncome().Show();
            this.Hide();

        }

        private void membersBTN_Click(object sender, EventArgs e)
        {
            new members().Show();
            this.Hide();
        }

        private void dashFamiliesButton_Click(object sender, EventArgs e)
        {
            new Families().Show();
            this.Hide();
        }

        private void groupsnFunctionsBTN_Click(object sender, EventArgs e)
        {
            new GroupsAndFunctions().Show();
            this.Hide();
        }

       
       
    }
}
