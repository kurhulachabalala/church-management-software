﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wrs_management
{
    public partial class Families : Form
    {
        int MemberID = 0;
        string dest = "";


        public Families()
        {
            dest = "dash";
            InitializeComponent();
        }
        public Families(int memberID)
        {
            dest = "members";
            InitializeComponent();
            MemberID = memberID;
        }

        

        private void BackButton_Click(object sender, EventArgs e)
        {
            if (dest == "dash")
            {
                new dashboard().Show();
                this.Dispose();

            }
            else
            {
                    this.Dispose();
            }
            
        }

        private void Families_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void Families_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'wrsMembersDataSet.families' table. You can move, or remove it, as needed.
            this.familiesTableAdapter.Fill(this.wrsMembersDataSet.families);

        }

        

       

      

       
       
    }
}
