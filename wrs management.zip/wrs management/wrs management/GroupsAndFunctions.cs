﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
 * this form . the groups and functions is used to manage groups/ functions/ tasks in relation to church member
 * */
namespace wrs_management
{
    public partial class GroupsAndFunctions : Form
    {
        // declearing all variables to be used by the form in this class
        int groupMemberID,memberdetailsID,GroupID;//variables for storing the product keys to be used for processing
        
        string loc, clickedButton = "";
       

        public GroupsAndFunctions()
        {
            InitializeComponent();
            this.loc = "dash";
        }
        public GroupsAndFunctions(int memberID)
        {
            InitializeComponent();
            this.groupMemberID = memberID;
            this.loc = "members";
        }

        private void GroupsAndFunctions_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'wrsMembersDataSet.GroupsFunction' table. You can move, or remove it, as needed.
            this.groupsFunctionTableAdapter.Fill(this.wrsMembersDataSet.GroupsFunction);
            // TODO: This line of code loads data into the 'wrsMembersDataSet.memberDetails' table. You can move, or remove it, as needed.
            this.memberDetailsTableAdapter.Fill(this.wrsMembersDataSet.memberDetails);
           


            // ading checkbox to datagridview

            //DataGridViewCheckBoxColumn checkColumn = new DataGridViewCheckBoxColumn();
            //checkColumn.Name = "X";
            //checkColumn.HeaderText = "X";
            //checkColumn.Width = 50;
            //checkColumn.ReadOnly = false;
            //checkColumn.FillWeight = 10; //if the datagridview is resized (on form resize) the checkbox won't take up too much; value is relative to the other columns' fill values
            // groupsFunctionsDataGridView.Columns.Add(checkColumn);

        }
        // Button to navigate back to the previous form by checking which contructor called it
        private void backButton_Click(object sender, EventArgs e)
        {
            if (loc == "members")
            {
                
                this.Dispose();

            }
            else
            {
                new dashboard().Show();
                this.Dispose();

            }
            
        }
        // function to exit the app when form is closed
        private void GroupsAndFunctions_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        // still to edit
        private void funchtionsCheckBox_MouseClick(object sender, MouseEventArgs e)
        {

            if (AllCheckBox.Checked == true)
            {
                groupCheckBox.Checked = taskCheckBox.Checked = funchtionsCheckBox.Checked = false;

            }
            else
            {
                if (groupCheckBox.Checked == true)
                {
                    AllCheckBox.Checked = taskCheckBox.Checked = funchtionsCheckBox.Checked = false;
                }
                else
                {
                    if (taskCheckBox.Checked == true)
                    {

                    }
                    else
                    {
                        if (funchtionsCheckBox.Checked == true)
                        {
                            AllCheckBox.Checked = taskCheckBox.Checked = groupCheckBox.Checked = false;
                        }
                    }
                }

            }

        }



        void selRow(int selIndex)
        {
            //groupID
            GroupID = Convert.ToInt16(groupsFunctionsDataGridView.Rows[selIndex].Cells[0].Value);
            
           // selectedMemberID = Convert.ToInt32(groupsFunctionsDataGridView.Rows[selIndex].Cells[1].Value);
            //details

            // groupName
            groupsFunctionNametextBox.Text = groupsFunctionsDataGridView.Rows[selIndex].Cells[1].Value.ToString();

            // groupType
            groupsFunctionTypecomboBox.Text = groupsFunctionsDataGridView.Rows[selIndex].Cells[2].Value.ToString();
            //GFDiscription
            groupsFunctionDescriptionrichTextBox.Text = groupsFunctionsDataGridView.Rows[selIndex].Cells[3].Value.ToString();
            //MissionStatement
            GroupMissionRichTextBox.Text = groupsFunctionsDataGridView.Rows[selIndex].Cells[4].Value.ToString();
            //Role
            groupsFunctionRolesComboBox.Text = groupsFunctionsDataGridView.Rows[selIndex].Cells[1].Value.ToString();
            //oleDiscription
            roleDiscriptionrichTextBox.Text = groupsFunctionsDataGridView.Rows[selIndex].Cells[1].Value.ToString();
            
            //startDate
            GroupFunctionStartDateTimePicker.Value =Convert.ToDateTime( groupsFunctionsDataGridView.Rows[selIndex].Cells[5].Value);
            //EndDate
            groupsFunctionsEndDateTimePicker.Value = Convert.ToDateTime(groupsFunctionsDataGridView.Rows[selIndex].Cells[6].Value);


            // communications
            screenRichTextBox.Text = groupsFunctionsDataGridView.Rows[selIndex].Cells[1].Value.ToString();

            //messageRichTextBox.Text

            //function fill group members datagridview
            groupMembersDataGridView.DataSource = groupsFunctionsDataGridView.Rows[selIndex].Cells[1].Value.ToString();
        }


        // method to clear data in controls 
        private void clearControls()
        {
            foreach (Control c in GroupDetails.Controls)
            {
                if (c is Label || c is Button || c is CheckBox)
                {
                    

                }
                else
                {
                    c.Text = "";
                    groupsFunctionTypecomboBox.SelectedItem = groupsFunctionRolesComboBox.SelectedItem = null;

                    GroupFunctionStartDateTimePicker.Value = groupsFunctionsEndDateTimePicker.Value = DateTime.Now;
                }
            }

            foreach (Control c in Communication.Controls)
            {
                if (c is Label || c is Button || c is CheckBox)
                {


                }
                else
                {
                    c.Text = "";
                    
                }
            }


            GroupID = groupMemberID = -1;
            clickedButton = "";


        }

        //method to enable functions 
        private void enableControlls() 
        { 
            //enable controls in the group details tab page and disable buttons outside
             foreach (Control c in GroupDetails.Controls)
            {
                c.Enabled = true;
                taskSaveButton.Visible = GFCancelButton.Visible = true;
                addGroupButton.Enabled = editGroupButton.Enabled = deleteGroupButton.Enabled = false;
                
            }
            //enable controls in the communications tab page
             foreach (Control c in Communication.Controls)
             {
                 c.Enabled = true;
             }
                         

        }

        //method to disable controls in groups and functions form
        private void disableControls()
        {  
            //disable controls in the group details tab page and enable buttons outside
            foreach (Control c in GroupDetails.Controls)
            {
                c.Enabled = false;
                taskSaveButton.Visible = GFCancelButton.Visible = false;
                addGroupButton.Enabled = editGroupButton.Enabled = deleteGroupButton.Enabled = true;
                clearControls();
            }
            
            //disable controls in the communications tab page
            foreach (Control c in Communication.Controls)
            {
                c.Enabled = false;
               
            }
 
        }


        //method to help select a row and assign data to other vvariables snd controls of the class
        private void groupsFunctionsDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // method called to clear controls if previusly populated so that accurate infor is shown
            clearControls();
            //function to identify the selected row and call the function tat desplays infor relating to the row
            if (e.RowIndex >= 0)
            {
                selRow(e.RowIndex);
            }
            
        }

        // setting button click events to performed desired function 
        private void addGroupButton_Click(object sender, EventArgs e)
        {
            clickedButton = "AddBTN";
            enableControlls();
            clearControls();
            

        }

        private void editGroupButton_Click(object sender, EventArgs e)
        {
            clickedButton = "editBTN";
            enableControlls(); 
            clearControls();
           

        }

        private void deleteGroupButton_Click(object sender, EventArgs e)
        {
            clickedButton = "deleteBTN";
            enableControlls();
            clearControls();
            

        }
    
    
    }


}

        

        

     
    

