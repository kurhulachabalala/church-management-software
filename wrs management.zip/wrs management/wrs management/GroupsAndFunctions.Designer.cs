﻿namespace wrs_management
{
    partial class GroupsAndFunctions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GroupsAndFunctions));
            this.groupsFunctionsDataGridView = new System.Windows.Forms.DataGridView();
            this.backButton = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.GroupDetails = new System.Windows.Forms.TabPage();
            this.groupMembersDataGridView = new System.Windows.Forms.DataGridView();
            this.groupsFunctionTypecomboBox = new System.Windows.Forms.ComboBox();
            this.groupsFunctionRolesComboBox = new System.Windows.Forms.ComboBox();
            this.GroupFunctionStartDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.groupsFunctionsEndDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.roleDiscriptionrichTextBox = new System.Windows.Forms.RichTextBox();
            this.GroupMissionRichTextBox = new System.Windows.Forms.RichTextBox();
            this.groupsFunctionDescriptionrichTextBox = new System.Windows.Forms.RichTextBox();
            this.groupsFunctionNametextBox = new System.Windows.Forms.TextBox();
            this.groupsFunctionTypelabel = new System.Windows.Forms.Label();
            this.membersLabel = new System.Windows.Forms.Label();
            this.GroupFunctionStartDatelabel = new System.Windows.Forms.Label();
            this.groupsFunctionNamelable = new System.Windows.Forms.Label();
            this.roleDiscriptionLabel = new System.Windows.Forms.Label();
            this.GroupMissionLable = new System.Windows.Forms.Label();
            this.taskDueDatelabel = new System.Windows.Forms.Label();
            this.groupsFunctionDescriptionLabel = new System.Windows.Forms.Label();
            this.groupsFunctionMemberRolelabel = new System.Windows.Forms.Label();
            this.Communication = new System.Windows.Forms.TabPage();
            this.MassegeLable = new System.Windows.Forms.Label();
            this.messageRichTextBox = new System.Windows.Forms.RichTextBox();
            this.screenRichTextBox = new System.Windows.Forms.RichTextBox();
            this.sendButton = new System.Windows.Forms.Button();
            this.editGroupButton = new System.Windows.Forms.Button();
            this.deleteGroupButton = new System.Windows.Forms.Button();
            this.addGroupButton = new System.Windows.Forms.Button();
            this.GFCancelButton = new System.Windows.Forms.Button();
            this.taskSaveButton = new System.Windows.Forms.Button();
            this.AllCheckBox = new System.Windows.Forms.CheckBox();
            this.taskCheckBox = new System.Windows.Forms.CheckBox();
            this.groupCheckBox = new System.Windows.Forms.CheckBox();
            this.funchtionsCheckBox = new System.Windows.Forms.CheckBox();
            this.groupsFunctionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wrsMembersDataSet = new wrs_management.wrsMembersDataSet();
            this.memberDetailsTableAdapter = new wrs_management.wrsMembersDataSetTableAdapters.memberDetailsTableAdapter();
            this.groupsFunctionTableAdapter = new wrs_management.wrsMembersDataSetTableAdapters.GroupsFunctionTableAdapter();
            this.groupFunctionIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.missionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionsDataGridView)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.GroupDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupMembersDataGridView)).BeginInit();
            this.Communication.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrsMembersDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupsFunctionsDataGridView
            // 
            this.groupsFunctionsDataGridView.AllowUserToAddRows = false;
            this.groupsFunctionsDataGridView.AllowUserToDeleteRows = false;
            this.groupsFunctionsDataGridView.AutoGenerateColumns = false;
            this.groupsFunctionsDataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.groupsFunctionsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.groupsFunctionsDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.groupsFunctionsDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.groupsFunctionsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.groupsFunctionsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.groupFunctionIDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.discriptionDataGridViewTextBoxColumn,
            this.missionDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn});
            this.groupsFunctionsDataGridView.DataSource = this.groupsFunctionBindingSource;
            this.groupsFunctionsDataGridView.GridColor = System.Drawing.SystemColors.Control;
            this.groupsFunctionsDataGridView.Location = new System.Drawing.Point(0, 122);
            this.groupsFunctionsDataGridView.Name = "groupsFunctionsDataGridView";
            this.groupsFunctionsDataGridView.ReadOnly = true;
            this.groupsFunctionsDataGridView.RowHeadersVisible = false;
            this.groupsFunctionsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.groupsFunctionsDataGridView.Size = new System.Drawing.Size(200, 399);
            this.groupsFunctionsDataGridView.TabIndex = 44;
            this.groupsFunctionsDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.groupsFunctionsDataGridView_CellClick);
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(12, 534);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 23);
            this.backButton.TabIndex = 33;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.GroupDetails);
            this.tabControl1.Controls.Add(this.Communication);
            this.tabControl1.Location = new System.Drawing.Point(218, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(562, 539);
            this.tabControl1.TabIndex = 47;
            // 
            // GroupDetails
            // 
            this.GroupDetails.Controls.Add(this.groupMembersDataGridView);
            this.GroupDetails.Controls.Add(this.groupsFunctionTypecomboBox);
            this.GroupDetails.Controls.Add(this.groupsFunctionRolesComboBox);
            this.GroupDetails.Controls.Add(this.GroupFunctionStartDateTimePicker);
            this.GroupDetails.Controls.Add(this.groupsFunctionsEndDateTimePicker);
            this.GroupDetails.Controls.Add(this.roleDiscriptionrichTextBox);
            this.GroupDetails.Controls.Add(this.GroupMissionRichTextBox);
            this.GroupDetails.Controls.Add(this.groupsFunctionDescriptionrichTextBox);
            this.GroupDetails.Controls.Add(this.groupsFunctionNametextBox);
            this.GroupDetails.Controls.Add(this.groupsFunctionTypelabel);
            this.GroupDetails.Controls.Add(this.membersLabel);
            this.GroupDetails.Controls.Add(this.GroupFunctionStartDatelabel);
            this.GroupDetails.Controls.Add(this.groupsFunctionNamelable);
            this.GroupDetails.Controls.Add(this.roleDiscriptionLabel);
            this.GroupDetails.Controls.Add(this.GroupMissionLable);
            this.GroupDetails.Controls.Add(this.taskDueDatelabel);
            this.GroupDetails.Controls.Add(this.groupsFunctionDescriptionLabel);
            this.GroupDetails.Controls.Add(this.groupsFunctionMemberRolelabel);
            this.GroupDetails.Location = new System.Drawing.Point(4, 22);
            this.GroupDetails.Name = "GroupDetails";
            this.GroupDetails.Padding = new System.Windows.Forms.Padding(3);
            this.GroupDetails.Size = new System.Drawing.Size(554, 513);
            this.GroupDetails.TabIndex = 0;
            this.GroupDetails.Text = "Group Details";
            this.GroupDetails.UseVisualStyleBackColor = true;
            // 
            // groupMembersDataGridView
            // 
            this.groupMembersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.groupMembersDataGridView.Location = new System.Drawing.Point(6, 42);
            this.groupMembersDataGridView.Name = "groupMembersDataGridView";
            this.groupMembersDataGridView.Size = new System.Drawing.Size(194, 436);
            this.groupMembersDataGridView.TabIndex = 60;
            // 
            // groupsFunctionTypecomboBox
            // 
            this.groupsFunctionTypecomboBox.FormattingEnabled = true;
            this.groupsFunctionTypecomboBox.Items.AddRange(new object[] {
            "Group",
            "Task",
            "Functions"});
            this.groupsFunctionTypecomboBox.Location = new System.Drawing.Point(341, 56);
            this.groupsFunctionTypecomboBox.Name = "groupsFunctionTypecomboBox";
            this.groupsFunctionTypecomboBox.Size = new System.Drawing.Size(121, 21);
            this.groupsFunctionTypecomboBox.TabIndex = 58;
            // 
            // groupsFunctionRolesComboBox
            // 
            this.groupsFunctionRolesComboBox.FormattingEnabled = true;
            this.groupsFunctionRolesComboBox.Location = new System.Drawing.Point(341, 99);
            this.groupsFunctionRolesComboBox.Name = "groupsFunctionRolesComboBox";
            this.groupsFunctionRolesComboBox.Size = new System.Drawing.Size(121, 21);
            this.groupsFunctionRolesComboBox.TabIndex = 59;
            // 
            // GroupFunctionStartDateTimePicker
            // 
            this.GroupFunctionStartDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.GroupFunctionStartDateTimePicker.Location = new System.Drawing.Point(310, 421);
            this.GroupFunctionStartDateTimePicker.Name = "GroupFunctionStartDateTimePicker";
            this.GroupFunctionStartDateTimePicker.Size = new System.Drawing.Size(120, 20);
            this.GroupFunctionStartDateTimePicker.TabIndex = 56;
            // 
            // groupsFunctionsEndDateTimePicker
            // 
            this.groupsFunctionsEndDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.groupsFunctionsEndDateTimePicker.Location = new System.Drawing.Point(310, 458);
            this.groupsFunctionsEndDateTimePicker.Name = "groupsFunctionsEndDateTimePicker";
            this.groupsFunctionsEndDateTimePicker.Size = new System.Drawing.Size(120, 20);
            this.groupsFunctionsEndDateTimePicker.TabIndex = 57;
            // 
            // roleDiscriptionrichTextBox
            // 
            this.roleDiscriptionrichTextBox.Location = new System.Drawing.Point(243, 158);
            this.roleDiscriptionrichTextBox.Name = "roleDiscriptionrichTextBox";
            this.roleDiscriptionrichTextBox.Size = new System.Drawing.Size(256, 60);
            this.roleDiscriptionrichTextBox.TabIndex = 54;
            this.roleDiscriptionrichTextBox.Text = "";
            // 
            // GroupMissionRichTextBox
            // 
            this.GroupMissionRichTextBox.Location = new System.Drawing.Point(243, 248);
            this.GroupMissionRichTextBox.Name = "GroupMissionRichTextBox";
            this.GroupMissionRichTextBox.Size = new System.Drawing.Size(256, 60);
            this.GroupMissionRichTextBox.TabIndex = 55;
            this.GroupMissionRichTextBox.Text = "";
            // 
            // groupsFunctionDescriptionrichTextBox
            // 
            this.groupsFunctionDescriptionrichTextBox.Location = new System.Drawing.Point(243, 341);
            this.groupsFunctionDescriptionrichTextBox.Name = "groupsFunctionDescriptionrichTextBox";
            this.groupsFunctionDescriptionrichTextBox.Size = new System.Drawing.Size(256, 60);
            this.groupsFunctionDescriptionrichTextBox.TabIndex = 55;
            this.groupsFunctionDescriptionrichTextBox.Text = "";
            // 
            // groupsFunctionNametextBox
            // 
            this.groupsFunctionNametextBox.Location = new System.Drawing.Point(341, 14);
            this.groupsFunctionNametextBox.Name = "groupsFunctionNametextBox";
            this.groupsFunctionNametextBox.Size = new System.Drawing.Size(100, 20);
            this.groupsFunctionNametextBox.TabIndex = 53;
            // 
            // groupsFunctionTypelabel
            // 
            this.groupsFunctionTypelabel.AutoSize = true;
            this.groupsFunctionTypelabel.Location = new System.Drawing.Point(243, 56);
            this.groupsFunctionTypelabel.Name = "groupsFunctionTypelabel";
            this.groupsFunctionTypelabel.Size = new System.Drawing.Size(31, 13);
            this.groupsFunctionTypelabel.TabIndex = 45;
            this.groupsFunctionTypelabel.Text = "Type";
            // 
            // membersLabel
            // 
            this.membersLabel.AutoSize = true;
            this.membersLabel.Location = new System.Drawing.Point(3, 21);
            this.membersLabel.Name = "membersLabel";
            this.membersLabel.Size = new System.Drawing.Size(45, 13);
            this.membersLabel.TabIndex = 46;
            this.membersLabel.Text = "Member";
            // 
            // GroupFunctionStartDatelabel
            // 
            this.GroupFunctionStartDatelabel.AutoSize = true;
            this.GroupFunctionStartDatelabel.Location = new System.Drawing.Point(243, 425);
            this.GroupFunctionStartDatelabel.Name = "GroupFunctionStartDatelabel";
            this.GroupFunctionStartDatelabel.Size = new System.Drawing.Size(55, 13);
            this.GroupFunctionStartDatelabel.TabIndex = 48;
            this.GroupFunctionStartDatelabel.Text = "Start Date";
            // 
            // groupsFunctionNamelable
            // 
            this.groupsFunctionNamelable.AutoSize = true;
            this.groupsFunctionNamelable.Location = new System.Drawing.Point(243, 18);
            this.groupsFunctionNamelable.Name = "groupsFunctionNamelable";
            this.groupsFunctionNamelable.Size = new System.Drawing.Size(35, 13);
            this.groupsFunctionNamelable.TabIndex = 47;
            this.groupsFunctionNamelable.Text = "Name";
            // 
            // roleDiscriptionLabel
            // 
            this.roleDiscriptionLabel.AutoSize = true;
            this.roleDiscriptionLabel.Location = new System.Drawing.Point(243, 140);
            this.roleDiscriptionLabel.Name = "roleDiscriptionLabel";
            this.roleDiscriptionLabel.Size = new System.Drawing.Size(87, 13);
            this.roleDiscriptionLabel.TabIndex = 50;
            this.roleDiscriptionLabel.Text = "Role Discription :";
            // 
            // GroupMissionLable
            // 
            this.GroupMissionLable.AutoSize = true;
            this.GroupMissionLable.Location = new System.Drawing.Point(243, 230);
            this.GroupMissionLable.Name = "GroupMissionLable";
            this.GroupMissionLable.Size = new System.Drawing.Size(99, 13);
            this.GroupMissionLable.TabIndex = 51;
            this.GroupMissionLable.Text = "Mission Statement :";
            // 
            // taskDueDatelabel
            // 
            this.taskDueDatelabel.AutoSize = true;
            this.taskDueDatelabel.Location = new System.Drawing.Point(243, 462);
            this.taskDueDatelabel.Name = "taskDueDatelabel";
            this.taskDueDatelabel.Size = new System.Drawing.Size(53, 13);
            this.taskDueDatelabel.TabIndex = 49;
            this.taskDueDatelabel.Text = "Due Date";
            // 
            // groupsFunctionDescriptionLabel
            // 
            this.groupsFunctionDescriptionLabel.AutoSize = true;
            this.groupsFunctionDescriptionLabel.Location = new System.Drawing.Point(243, 323);
            this.groupsFunctionDescriptionLabel.Name = "groupsFunctionDescriptionLabel";
            this.groupsFunctionDescriptionLabel.Size = new System.Drawing.Size(147, 13);
            this.groupsFunctionDescriptionLabel.TabIndex = 51;
            this.groupsFunctionDescriptionLabel.Text = "groups/Function Description :";
            // 
            // groupsFunctionMemberRolelabel
            // 
            this.groupsFunctionMemberRolelabel.AutoSize = true;
            this.groupsFunctionMemberRolelabel.Location = new System.Drawing.Point(243, 103);
            this.groupsFunctionMemberRolelabel.Name = "groupsFunctionMemberRolelabel";
            this.groupsFunctionMemberRolelabel.Size = new System.Drawing.Size(29, 13);
            this.groupsFunctionMemberRolelabel.TabIndex = 52;
            this.groupsFunctionMemberRolelabel.Text = "Role";
            // 
            // Communication
            // 
            this.Communication.Controls.Add(this.MassegeLable);
            this.Communication.Controls.Add(this.messageRichTextBox);
            this.Communication.Controls.Add(this.screenRichTextBox);
            this.Communication.Controls.Add(this.sendButton);
            this.Communication.Location = new System.Drawing.Point(4, 22);
            this.Communication.Name = "Communication";
            this.Communication.Padding = new System.Windows.Forms.Padding(3);
            this.Communication.Size = new System.Drawing.Size(554, 513);
            this.Communication.TabIndex = 1;
            this.Communication.Text = "Communication";
            this.Communication.UseVisualStyleBackColor = true;
            // 
            // MassegeLable
            // 
            this.MassegeLable.AutoSize = true;
            this.MassegeLable.Location = new System.Drawing.Point(26, 302);
            this.MassegeLable.Name = "MassegeLable";
            this.MassegeLable.Size = new System.Drawing.Size(56, 13);
            this.MassegeLable.TabIndex = 40;
            this.MassegeLable.Text = "Massege :";
            // 
            // messageRichTextBox
            // 
            this.messageRichTextBox.Enabled = false;
            this.messageRichTextBox.Location = new System.Drawing.Point(40, 321);
            this.messageRichTextBox.Name = "messageRichTextBox";
            this.messageRichTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.messageRichTextBox.Size = new System.Drawing.Size(488, 131);
            this.messageRichTextBox.TabIndex = 37;
            this.messageRichTextBox.Text = "";
            // 
            // screenRichTextBox
            // 
            this.screenRichTextBox.Enabled = false;
            this.screenRichTextBox.Location = new System.Drawing.Point(39, 5);
            this.screenRichTextBox.Name = "screenRichTextBox";
            this.screenRichTextBox.Size = new System.Drawing.Size(488, 231);
            this.screenRichTextBox.TabIndex = 39;
            this.screenRichTextBox.Text = "";
            // 
            // sendButton
            // 
            this.sendButton.Location = new System.Drawing.Point(40, 458);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(488, 50);
            this.sendButton.TabIndex = 38;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = true;
            this.sendButton.Visible = false;
            // 
            // editGroupButton
            // 
            this.editGroupButton.Location = new System.Drawing.Point(76, 6);
            this.editGroupButton.Name = "editGroupButton";
            this.editGroupButton.Size = new System.Drawing.Size(69, 48);
            this.editGroupButton.TabIndex = 42;
            this.editGroupButton.Text = "Edit Group";
            this.editGroupButton.UseVisualStyleBackColor = true;
            this.editGroupButton.Click += new System.EventHandler(this.editGroupButton_Click);
            // 
            // deleteGroupButton
            // 
            this.deleteGroupButton.Location = new System.Drawing.Point(150, 6);
            this.deleteGroupButton.Name = "deleteGroupButton";
            this.deleteGroupButton.Size = new System.Drawing.Size(69, 48);
            this.deleteGroupButton.TabIndex = 43;
            this.deleteGroupButton.Text = "Delete Group";
            this.deleteGroupButton.UseVisualStyleBackColor = true;
            this.deleteGroupButton.Click += new System.EventHandler(this.deleteGroupButton_Click);
            // 
            // addGroupButton
            // 
            this.addGroupButton.Location = new System.Drawing.Point(2, 6);
            this.addGroupButton.Name = "addGroupButton";
            this.addGroupButton.Size = new System.Drawing.Size(69, 48);
            this.addGroupButton.TabIndex = 41;
            this.addGroupButton.Text = "Add Group";
            this.addGroupButton.UseVisualStyleBackColor = true;
            this.addGroupButton.Click += new System.EventHandler(this.addGroupButton_Click);
            // 
            // GFCancelButton
            // 
            this.GFCancelButton.Location = new System.Drawing.Point(218, 544);
            this.GFCancelButton.Name = "GFCancelButton";
            this.GFCancelButton.Size = new System.Drawing.Size(75, 23);
            this.GFCancelButton.TabIndex = 49;
            this.GFCancelButton.Text = "Cancel";
            this.GFCancelButton.UseVisualStyleBackColor = true;
            this.GFCancelButton.Visible = false;
            // 
            // taskSaveButton
            // 
            this.taskSaveButton.Location = new System.Drawing.Point(705, 544);
            this.taskSaveButton.Name = "taskSaveButton";
            this.taskSaveButton.Size = new System.Drawing.Size(75, 23);
            this.taskSaveButton.TabIndex = 48;
            this.taskSaveButton.Text = "Save";
            this.taskSaveButton.UseVisualStyleBackColor = true;
            this.taskSaveButton.Visible = false;
            // 
            // AllCheckBox
            // 
            this.AllCheckBox.AutoSize = true;
            this.AllCheckBox.Checked = true;
            this.AllCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AllCheckBox.Location = new System.Drawing.Point(12, 75);
            this.AllCheckBox.Name = "AllCheckBox";
            this.AllCheckBox.Size = new System.Drawing.Size(37, 17);
            this.AllCheckBox.TabIndex = 50;
            this.AllCheckBox.Text = "All";
            this.AllCheckBox.UseVisualStyleBackColor = true;
            this.AllCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.funchtionsCheckBox_MouseClick);
            // 
            // taskCheckBox
            // 
            this.taskCheckBox.AutoSize = true;
            this.taskCheckBox.Location = new System.Drawing.Point(98, 75);
            this.taskCheckBox.Name = "taskCheckBox";
            this.taskCheckBox.Size = new System.Drawing.Size(50, 17);
            this.taskCheckBox.TabIndex = 50;
            this.taskCheckBox.Text = "Task";
            this.taskCheckBox.UseVisualStyleBackColor = true;
            this.taskCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.funchtionsCheckBox_MouseClick);
            // 
            // groupCheckBox
            // 
            this.groupCheckBox.AutoSize = true;
            this.groupCheckBox.Location = new System.Drawing.Point(12, 98);
            this.groupCheckBox.Name = "groupCheckBox";
            this.groupCheckBox.Size = new System.Drawing.Size(55, 17);
            this.groupCheckBox.TabIndex = 50;
            this.groupCheckBox.Text = "Group";
            this.groupCheckBox.UseVisualStyleBackColor = true;
            this.groupCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.funchtionsCheckBox_MouseClick);
            // 
            // funchtionsCheckBox
            // 
            this.funchtionsCheckBox.AutoSize = true;
            this.funchtionsCheckBox.Location = new System.Drawing.Point(98, 98);
            this.funchtionsCheckBox.Name = "funchtionsCheckBox";
            this.funchtionsCheckBox.Size = new System.Drawing.Size(78, 17);
            this.funchtionsCheckBox.TabIndex = 50;
            this.funchtionsCheckBox.Text = "Funchtions";
            this.funchtionsCheckBox.UseVisualStyleBackColor = true;
            this.funchtionsCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.funchtionsCheckBox_MouseClick);
            // 
            // groupsFunctionBindingSource
            // 
            this.groupsFunctionBindingSource.DataMember = "GroupsFunction";
            this.groupsFunctionBindingSource.DataSource = this.wrsMembersDataSet;
            // 
            // wrsMembersDataSet
            // 
            this.wrsMembersDataSet.DataSetName = "wrsMembersDataSet";
            this.wrsMembersDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // memberDetailsTableAdapter
            // 
            this.memberDetailsTableAdapter.ClearBeforeFill = true;
            // 
            // groupsFunctionTableAdapter
            // 
            this.groupsFunctionTableAdapter.ClearBeforeFill = true;
            // 
            // groupFunctionIDDataGridViewTextBoxColumn
            // 
            this.groupFunctionIDDataGridViewTextBoxColumn.DataPropertyName = "groupFunctionID";
            this.groupFunctionIDDataGridViewTextBoxColumn.HeaderText = "groupFunctionID";
            this.groupFunctionIDDataGridViewTextBoxColumn.Name = "groupFunctionIDDataGridViewTextBoxColumn";
            this.groupFunctionIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.groupFunctionIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 80;
            // 
            // discriptionDataGridViewTextBoxColumn
            // 
            this.discriptionDataGridViewTextBoxColumn.DataPropertyName = "discription";
            this.discriptionDataGridViewTextBoxColumn.HeaderText = "discription";
            this.discriptionDataGridViewTextBoxColumn.Name = "discriptionDataGridViewTextBoxColumn";
            this.discriptionDataGridViewTextBoxColumn.ReadOnly = true;
            this.discriptionDataGridViewTextBoxColumn.Width = 120;
            // 
            // missionDataGridViewTextBoxColumn
            // 
            this.missionDataGridViewTextBoxColumn.DataPropertyName = "mission";
            this.missionDataGridViewTextBoxColumn.HeaderText = "mission";
            this.missionDataGridViewTextBoxColumn.Name = "missionDataGridViewTextBoxColumn";
            this.missionDataGridViewTextBoxColumn.ReadOnly = true;
            this.missionDataGridViewTextBoxColumn.Visible = false;
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "startDate";
            this.startDateDataGridViewTextBoxColumn.HeaderText = "startDate";
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            this.startDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.startDateDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dataGridView1.DataSource = this.groupsFunctionBindingSource;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.Location = new System.Drawing.Point(352, 542);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(200, 25);
            this.dataGridView1.TabIndex = 51;
            this.dataGridView1.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "groupFunctionID";
            this.dataGridViewTextBoxColumn1.HeaderText = "groupFunctionID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "name";
            this.dataGridViewTextBoxColumn2.HeaderText = "name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 80;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "discription";
            this.dataGridViewTextBoxColumn3.HeaderText = "discription";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 120;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "mission";
            this.dataGridViewTextBoxColumn4.HeaderText = "mission";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "startDate";
            this.dataGridViewTextBoxColumn5.HeaderText = "startDate";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // GroupsAndFunctions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 569);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.funchtionsCheckBox);
            this.Controls.Add(this.groupCheckBox);
            this.Controls.Add(this.taskCheckBox);
            this.Controls.Add(this.AllCheckBox);
            this.Controls.Add(this.GFCancelButton);
            this.Controls.Add(this.taskSaveButton);
            this.Controls.Add(this.editGroupButton);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupsFunctionsDataGridView);
            this.Controls.Add(this.deleteGroupButton);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.addGroupButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GroupsAndFunctions";
            this.Text = "GroupsAndFunctions";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.GroupsAndFunctions_FormClosed);
            this.Load += new System.EventHandler(this.GroupsAndFunctions_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionsDataGridView)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.GroupDetails.ResumeLayout(false);
            this.GroupDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupMembersDataGridView)).EndInit();
            this.Communication.ResumeLayout(false);
            this.Communication.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupsFunctionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrsMembersDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView groupsFunctionsDataGridView;
        private wrsMembersDataSet wrsMembersDataSet;
        private wrsMembersDataSetTableAdapters.memberDetailsTableAdapter memberDetailsTableAdapter;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.BindingSource groupsFunctionBindingSource;
        private wrsMembersDataSetTableAdapters.GroupsFunctionTableAdapter groupsFunctionTableAdapter;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Communication;
        private System.Windows.Forms.TabPage GroupDetails;
        private System.Windows.Forms.DataGridView groupMembersDataGridView;
        private System.Windows.Forms.ComboBox groupsFunctionTypecomboBox;
        private System.Windows.Forms.ComboBox groupsFunctionRolesComboBox;
        private System.Windows.Forms.DateTimePicker GroupFunctionStartDateTimePicker;
        private System.Windows.Forms.DateTimePicker groupsFunctionsEndDateTimePicker;
        private System.Windows.Forms.RichTextBox roleDiscriptionrichTextBox;
        private System.Windows.Forms.RichTextBox groupsFunctionDescriptionrichTextBox;
        private System.Windows.Forms.TextBox groupsFunctionNametextBox;
        private System.Windows.Forms.Label groupsFunctionTypelabel;
        private System.Windows.Forms.Label membersLabel;
        private System.Windows.Forms.Label GroupFunctionStartDatelabel;
        private System.Windows.Forms.Label groupsFunctionNamelable;
        private System.Windows.Forms.Label roleDiscriptionLabel;
        private System.Windows.Forms.Label taskDueDatelabel;
        private System.Windows.Forms.Label groupsFunctionDescriptionLabel;
        private System.Windows.Forms.Label groupsFunctionMemberRolelabel;
        private System.Windows.Forms.Label MassegeLable;
        private System.Windows.Forms.RichTextBox messageRichTextBox;
        private System.Windows.Forms.RichTextBox screenRichTextBox;
        private System.Windows.Forms.Button sendButton;
        private System.Windows.Forms.Button editGroupButton;
        private System.Windows.Forms.Button deleteGroupButton;
        private System.Windows.Forms.Button addGroupButton;
        private System.Windows.Forms.RichTextBox GroupMissionRichTextBox;
        private System.Windows.Forms.Label GroupMissionLable;
        private System.Windows.Forms.Button GFCancelButton;
        private System.Windows.Forms.Button taskSaveButton;
        private System.Windows.Forms.CheckBox AllCheckBox;
        private System.Windows.Forms.CheckBox taskCheckBox;
        private System.Windows.Forms.CheckBox groupCheckBox;
        private System.Windows.Forms.CheckBox funchtionsCheckBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn groupFunctionIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn discriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn missionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}